﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testeProj
{
    public static class Variaveis
    {
        public static string Continuar { get; set; }

        // Se usar SQL Server Express:
        public static string strConn = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=db_Biblioteca;User ID=sa;Password=123456;";
    }
}
