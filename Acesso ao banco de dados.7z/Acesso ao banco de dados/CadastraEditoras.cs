﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Acesso_ao_banco_de_dados
{
    public partial class CadastraEditoras : Form
    {
        public string sql;
        public CadastraEditoras()
        {
            InitializeComponent();
        }

        private void btnCadastrarEditora_Click(object sender, EventArgs e)
        {
            sql = "INSERT INTO tbl_Editoras(Nome_Autor) VALUES ('" + txtEditora.Text + "');";

            MessageBox.Show(sql);
            ComandosDML inserir = new ComandosDML();
            try
            {
                inserir.iud(sql);
                MessageBox.Show("Registro inserido");
            }
            catch (SqlException s)
            {
                MessageBox.Show(s.Source.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Source.ToString());
            }
            finally
            {
                this.Hide();
            }
        }
    }
}
