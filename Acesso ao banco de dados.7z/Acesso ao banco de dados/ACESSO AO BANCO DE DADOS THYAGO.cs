﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Acesso_ao_banco_de_dados
{
    public partial class Form1 : Form
    {
        public string consulta;
        public string sql;
       
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Carrega Combobox com método da classe CarregaComboBox e listas:
            string Consulta = "SELECT Nome_Livro FROM tbl_livro";
            CarregaComboBox carregaLivros =  new CarregaComboBox();

            // Criar objeto de lista para armazenar os dados dos livros:
            List<string> Livros = new List<string>();
            Livros.AddRange(carregaLivros.carregaComboBox(Consulta, "Nome_Livro"));

            // Copia dados da lista para o combobox:
            cmbLivros.Items.AddRange(Livros.ToArray());
        }

        private void bntConsulta_Click(object sender, EventArgs e)
        {
            consulta = "SELECT L.Nome_Livro, L.Preco_Livro, L.Data_Pub, " +
                "A.Nome_Autor FROM tbl_Livro AS L INNER JOIN tbl_autores AS A " +
                "ON L.ID_autor = A.ID_Autor WHERE ID_Livro = " + txtCodLivro.Text;

            ConsultarLivros consultarLivros = new ConsultarLivros();

            consultarLivros.fazerconsulta(consulta);

            txtNomeLivro.Text = Variaveis.CaixaTxtNomeLivro;
            txtNomeAutor.Text = Variaveis.CaixaTxtNomeAutor;
            txtPrecoLivro.Text = Variaveis.CaixaTxtPrecoLivro;
            txtDataPub.Text = Variaveis.CaixaTxtDataPub.ToString("dd/MM/yyyy");
        }

        private void cmbLivros_SelectedIndexChanged(object sender, EventArgs e)
        {
            consulta = "SELECT L.Nome_Livro, L.Preco_Livro, L.Data_Pub, A.Nome_Autor" + 
            "FROM tbl_livro AS L INNER JOIN tbl_autored AS A " + 
            "ON L.ID_autor = A.Id_Autor" +
            "WHERE L.Nome_Livro =  '" + cmbLivros.SelectedItem.ToString() + "'";
            //Passa a string SQL para o método fazerConsulta:
            ConsultarLivros consultarLivros = new ConsultarLivros();
            consultarLivros.fazerconsulta(consulta);
            txtNomeLivro.Text = Variaveis.CaixaTxtNomeLivro;
            txtNomeAutor.Text = Variaveis.CaixaTxtNomeAutor;
            txtPrecoLivro.Text = Variaveis.CaixaTxtPrecoLivro;
            txtDataPub.Text = Variaveis.CaixaTxtDataPub.ToString("dd/MM/yyyy");
        }

        private void cadastroToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void editorasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CadastraEditoras cadastraEditoras = new CadastraEditoras();
            cadastraEditoras.Show();
        }

        private void autoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CadastraAutor cadastraEditoras = new CadastraAutor();
            cadastraEditoras.Show();
        }

        private void livrosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CadastraLivro cadastraEditoras = new CadastraLivro();
            cadastraEditoras.Show();
        }

        private void usúariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CadastraUser cadastraEditoras = new CadastraUser();
            cadastraEditoras.Show();
        }

        private void autoresToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ConsultaAutorEditora consulta = new ConsultaAutorEditora();
            Variaveis.ConsultaSelecionada = "Autores";
            consulta.Show();
        }

        private void editorasToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ConsultaAutorEditora consulta = new ConsultaAutorEditora();
            Variaveis.ConsultaSelecionada = "Editoras";
            consulta.Show();
        }

        private void consultaToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void livrosEmGridToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GridLivros gridLivros = new GridLivros();
            gridLivros.Show();
        }
    }
}
