﻿namespace Acesso_ao_banco_de_dados
{
    partial class CadastraLivro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCadastroLivro = new System.Windows.Forms.Label();
            this.lblPrecoLivro = new System.Windows.Forms.Label();
            this.lblISBN = new System.Windows.Forms.Label();
            this.lblDataPub = new System.Windows.Forms.Label();
            this.lblNomeEditora = new System.Windows.Forms.Label();
            this.lblNomeLivro = new System.Windows.Forms.Label();
            this.lblNomeAutor = new System.Windows.Forms.Label();
            this.txtNomeLivro = new System.Windows.Forms.TextBox();
            this.txtISBN = new System.Windows.Forms.TextBox();
            this.txtPrecoLivro = new System.Windows.Forms.TextBox();
            this.cmbIDAutor = new System.Windows.Forms.ComboBox();
            this.cmbIDEditora = new System.Windows.Forms.ComboBox();
            this.btnCadastrarLivro = new System.Windows.Forms.Button();
            this.dtpDataPub = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // lblCadastroLivro
            // 
            this.lblCadastroLivro.AutoSize = true;
            this.lblCadastroLivro.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCadastroLivro.Location = new System.Drawing.Point(29, 37);
            this.lblCadastroLivro.Name = "lblCadastroLivro";
            this.lblCadastroLivro.Size = new System.Drawing.Size(328, 17);
            this.lblCadastroLivro.TabIndex = 0;
            this.lblCadastroLivro.Text = "Preencha os campos abaixo para cadastrar um livro:";
            // 
            // lblPrecoLivro
            // 
            this.lblPrecoLivro.AutoSize = true;
            this.lblPrecoLivro.Location = new System.Drawing.Point(31, 307);
            this.lblPrecoLivro.Name = "lblPrecoLivro";
            this.lblPrecoLivro.Size = new System.Drawing.Size(79, 13);
            this.lblPrecoLivro.TabIndex = 1;
            this.lblPrecoLivro.Text = "Preço do Livro:";
            // 
            // lblISBN
            // 
            this.lblISBN.AutoSize = true;
            this.lblISBN.Location = new System.Drawing.Point(31, 152);
            this.lblISBN.Name = "lblISBN";
            this.lblISBN.Size = new System.Drawing.Size(35, 13);
            this.lblISBN.TabIndex = 2;
            this.lblISBN.Text = "ISBN:";
            // 
            // lblDataPub
            // 
            this.lblDataPub.AutoSize = true;
            this.lblDataPub.Location = new System.Drawing.Point(31, 254);
            this.lblDataPub.Name = "lblDataPub";
            this.lblDataPub.Size = new System.Drawing.Size(104, 13);
            this.lblDataPub.TabIndex = 3;
            this.lblDataPub.Text = "Data de Publicação:";
            // 
            // lblNomeEditora
            // 
            this.lblNomeEditora.AutoSize = true;
            this.lblNomeEditora.Location = new System.Drawing.Point(31, 353);
            this.lblNomeEditora.Name = "lblNomeEditora";
            this.lblNomeEditora.Size = new System.Drawing.Size(89, 13);
            this.lblNomeEditora.TabIndex = 4;
            this.lblNomeEditora.Text = "Nome da Editora:";
            // 
            // lblNomeLivro
            // 
            this.lblNomeLivro.AutoSize = true;
            this.lblNomeLivro.Location = new System.Drawing.Point(31, 105);
            this.lblNomeLivro.Name = "lblNomeLivro";
            this.lblNomeLivro.Size = new System.Drawing.Size(79, 13);
            this.lblNomeLivro.TabIndex = 5;
            this.lblNomeLivro.Text = "Nome do Livro:";
            // 
            // lblNomeAutor
            // 
            this.lblNomeAutor.AutoSize = true;
            this.lblNomeAutor.Location = new System.Drawing.Point(29, 204);
            this.lblNomeAutor.Name = "lblNomeAutor";
            this.lblNomeAutor.Size = new System.Drawing.Size(81, 13);
            this.lblNomeAutor.TabIndex = 6;
            this.lblNomeAutor.Text = "Nome do Autor:";
            // 
            // txtNomeLivro
            // 
            this.txtNomeLivro.Location = new System.Drawing.Point(151, 98);
            this.txtNomeLivro.Name = "txtNomeLivro";
            this.txtNomeLivro.Size = new System.Drawing.Size(184, 20);
            this.txtNomeLivro.TabIndex = 7;
            // 
            // txtISBN
            // 
            this.txtISBN.Location = new System.Drawing.Point(151, 149);
            this.txtISBN.Name = "txtISBN";
            this.txtISBN.Size = new System.Drawing.Size(167, 20);
            this.txtISBN.TabIndex = 8;
            // 
            // txtPrecoLivro
            // 
            this.txtPrecoLivro.Location = new System.Drawing.Point(151, 304);
            this.txtPrecoLivro.Name = "txtPrecoLivro";
            this.txtPrecoLivro.Size = new System.Drawing.Size(100, 20);
            this.txtPrecoLivro.TabIndex = 9;
            // 
            // cmbIDAutor
            // 
            this.cmbIDAutor.FormattingEnabled = true;
            this.cmbIDAutor.Location = new System.Drawing.Point(151, 201);
            this.cmbIDAutor.Name = "cmbIDAutor";
            this.cmbIDAutor.Size = new System.Drawing.Size(160, 21);
            this.cmbIDAutor.TabIndex = 11;
            this.cmbIDAutor.SelectedIndexChanged += new System.EventHandler(this.cmbIDAutor_SelectedIndexChanged);
            // 
            // cmbIDEditora
            // 
            this.cmbIDEditora.FormattingEnabled = true;
            this.cmbIDEditora.Location = new System.Drawing.Point(151, 350);
            this.cmbIDEditora.Name = "cmbIDEditora";
            this.cmbIDEditora.Size = new System.Drawing.Size(121, 21);
            this.cmbIDEditora.TabIndex = 12;
            this.cmbIDEditora.SelectedIndexChanged += new System.EventHandler(this.cmbIDEditora_SelectedIndexChanged);
            // 
            // btnCadastrarLivro
            // 
            this.btnCadastrarLivro.Location = new System.Drawing.Point(116, 431);
            this.btnCadastrarLivro.Name = "btnCadastrarLivro";
            this.btnCadastrarLivro.Size = new System.Drawing.Size(120, 42);
            this.btnCadastrarLivro.TabIndex = 13;
            this.btnCadastrarLivro.Text = "Cadastrar Livro";
            this.btnCadastrarLivro.UseVisualStyleBackColor = true;
            this.btnCadastrarLivro.Click += new System.EventHandler(this.btnCadastrarLivro_Click);
            // 
            // dtpDataPub
            // 
            this.dtpDataPub.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDataPub.Location = new System.Drawing.Point(151, 248);
            this.dtpDataPub.Name = "dtpDataPub";
            this.dtpDataPub.Size = new System.Drawing.Size(200, 20);
            this.dtpDataPub.TabIndex = 14;
            // 
            // CadastraLivro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(502, 551);
            this.Controls.Add(this.dtpDataPub);
            this.Controls.Add(this.btnCadastrarLivro);
            this.Controls.Add(this.cmbIDEditora);
            this.Controls.Add(this.cmbIDAutor);
            this.Controls.Add(this.txtPrecoLivro);
            this.Controls.Add(this.txtISBN);
            this.Controls.Add(this.txtNomeLivro);
            this.Controls.Add(this.lblNomeAutor);
            this.Controls.Add(this.lblNomeLivro);
            this.Controls.Add(this.lblNomeEditora);
            this.Controls.Add(this.lblDataPub);
            this.Controls.Add(this.lblISBN);
            this.Controls.Add(this.lblPrecoLivro);
            this.Controls.Add(this.lblCadastroLivro);
            this.Name = "CadastraLivro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CadastraLivro";
            this.Load += new System.EventHandler(this.CadastraLivro_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCadastroLivro;
        private System.Windows.Forms.Label lblPrecoLivro;
        private System.Windows.Forms.Label lblISBN;
        private System.Windows.Forms.Label lblDataPub;
        private System.Windows.Forms.Label lblNomeEditora;
        private System.Windows.Forms.Label lblNomeLivro;
        private System.Windows.Forms.Label lblNomeAutor;
        private System.Windows.Forms.TextBox txtNomeLivro;
        private System.Windows.Forms.TextBox txtISBN;
        private System.Windows.Forms.TextBox txtPrecoLivro;
        private System.Windows.Forms.ComboBox cmbIDAutor;
        private System.Windows.Forms.ComboBox cmbIDEditora;
        private System.Windows.Forms.Button btnCadastrarLivro;
        private System.Windows.Forms.DateTimePicker dtpDataPub;
    }
}