﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acesso_ao_banco_de_dados
{
    class ComandosDML
    {
        // Método para inserir, atualizar ou excluir registros:

        public void iud(string sql)
        {
            SqlConnection conn = new SqlConnection(Variaveis.strConn);
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
    }
}
