﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Acesso_ao_banco_de_dados
{
    public partial class CadastraLivro : Form
    {
        public string sql;
        public string IDEditora;
        public string IDAutor;
        public string NomeAutor;
        public string consultaAutor;
        public string consultaEditora;
        string SQLAutor = "SELECT Nome_Autor, Sobrenome_Autor FROM tbl_autores";
        string SQLEditora = "SELECT Nome_Editora FROM tbl_editora";
        public CadastraLivro()
        {
            InitializeComponent();
        }

        private void btnCadastrarLivro_Click(object sender, EventArgs e)
        {

        }

        private void CadastraLivro_Load(object sender, EventArgs e)
        {
            CarregaComboBox carregaAutores = new CarregaComboBox();
            List<string> Autores = new List<string>();
            Autores.AddRange(carregaAutores.carregaComboBoxAutores(SQLAutor, "Nome_Autor", "Sobrenome_Autor"));
            //Tranferir dados para combobox
            cmbIDAutor.Items.AddRange(Autores.ToArray());

            //Carrega ComboBox de Editoras
            CarregaComboBox carregaEditoras = new CarregaComboBox();
            List<string> Editoras = new List<string>();
            Editoras.AddRange(carregaEditoras.carregaComboBoxEditoras(SQLEditora, "Nome_Editora"));
            //Transferir dados para combobox
            cmbIDEditora.Items.AddRange(Editoras.ToArray());
        }

        private void cmbIDEditora_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Verifica Editor Selecionada
            consultaEditora = "SELECT ID_Editora FROM tl_editoras WHERE Nome_Editora = " + "'" + cmbIDEditora.SelectedItem.ToString() + "'";
            verificaEditoraSelecionada(consultaEditora);
        }

        private void cmbIDAutor_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Verifica Autor Selecionado:
            string nomeCompletoAutor = cmbIDAutor.SelectedItem.ToString();
            string[] partesnomeAutor = nomeCompletoAutor.Split(' ');
            string nomeAutor = partesnomeAutor[0];
            string sobrenomeAutor = partesnomeAutor[1];
            string consultaAutor = "SELECT ID_Autor FROM tbl_autores WHERE Nome_Autor = '" + nomeAutor + "' AND Sobrenome_Autor = '" + sobrenomeAutor + "'";
            MessageBox.Show(consultaAutor);
            verificaAutorSelecionado(consultaAutor);

        }
        public void verificaAutorSelecionado(string SQLconsultaAutor)
        {
            SqlConnection conn = new SqlConnection(Variaveis.strConn);
            conn.Open();
            SqlCommand comando = new SqlCommand(SQLconsultaAutor, conn);
            SqlDataReader drDados = null;
            drDados = comando.ExecuteReader();
            if (drDados.HasRows)
            {
                while (drDados.Read())
                {
                    IDAutor = drDados["ID.Autor"].ToString();
                }

            }
            else
            {
                MessageBox.Show("Código não encotrados");
            }
            drDados.Close();
            conn.Close();
        }
        public void verificaEditoraSelecionada(string SQLconsultaEditora)
        {
            SqlConnection conn = new SqlConnection(Variaveis.strConn);
            conn.Open();
            SqlCommand comando = new SqlCommand(SQLconsultaEditora, conn);
            SqlDataReader drDados = null;
            drDados = comando.ExecuteReader();
            if (drDados.HasRows)
            {
                while (drDados.Read())
                {
                    IDEditora = drDados["ID_Editoras"].ToString();
                }
            }
            else
            {
                MessageBox.Show("Código não encontrado");
            } 
            drDados.Close();
            conn.Close();
        }
    }
}
