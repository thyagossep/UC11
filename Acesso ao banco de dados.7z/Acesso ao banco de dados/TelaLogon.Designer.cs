﻿namespace Acesso_ao_banco_de_dados
{
    partial class TelaLogon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLogonUser = new System.Windows.Forms.TextBox();
            this.txtLogonSenha = new System.Windows.Forms.TextBox();
            this.btnLogon = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(261, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(210, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Digite o nome do usuário para logon:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(292, 175);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Digite a senha do usuário:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtLogonUser
            // 
            this.txtLogonUser.Location = new System.Drawing.Point(264, 87);
            this.txtLogonUser.Name = "txtLogonUser";
            this.txtLogonUser.Size = new System.Drawing.Size(207, 20);
            this.txtLogonUser.TabIndex = 2;
            // 
            // txtLogonSenha
            // 
            this.txtLogonSenha.Location = new System.Drawing.Point(264, 221);
            this.txtLogonSenha.Name = "txtLogonSenha";
            this.txtLogonSenha.Size = new System.Drawing.Size(207, 20);
            this.txtLogonSenha.TabIndex = 3;
            this.txtLogonSenha.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btnLogon
            // 
            this.btnLogon.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogon.Location = new System.Drawing.Point(309, 299);
            this.btnLogon.Name = "btnLogon";
            this.btnLogon.Size = new System.Drawing.Size(100, 43);
            this.btnLogon.TabIndex = 4;
            this.btnLogon.Text = "Entrar";
            this.btnLogon.UseVisualStyleBackColor = true;
            this.btnLogon.Click += new System.EventHandler(this.btnLogon_Click);
            // 
            // TelaLogon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLogon);
            this.Controls.Add(this.txtLogonSenha);
            this.Controls.Add(this.txtLogonUser);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "TelaLogon";
            this.Text = "Efetuar Logon no Sistema";
            this.Load += new System.EventHandler(this.TelaLogon_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtLogonUser;
        private System.Windows.Forms.TextBox txtLogonSenha;
        private System.Windows.Forms.Button btnLogon;
    }
}