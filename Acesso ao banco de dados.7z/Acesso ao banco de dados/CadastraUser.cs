﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Acesso_ao_banco_de_dados
{
    public partial class CadastraUser : Form
    {
        public CadastraUser()
        {
            InitializeComponent();
        }

        private void btnCadastrarUser_Click(object sender, EventArgs e)
        {
            if (txtCadastraSenha.Text.Equals(txtConfirmaSenha.Text))
            {
                Criptografia cripto = new Criptografia();
                string senha = cripto.HashSHA256(txtCadastraSenha.Text);

                //Criar string SQL:
                string sql = "INSERT INTO tbl_logon(Nome_user, Senha) VALUES ('" + txtCadastraNome.Text + "','" + senha + "')";
                MessageBox.Show(sql);
                ComandosDML inserir = new ComandosDML();
                try
                {
                    inserir.iud(sql);
                }
                catch (SqlException s)
                {
                    MessageBox.Show(s.Source.ToString());
                }
                finally 
                {
                    MessageBox.Show("Usuário Cadastrado");
                }
            }
            else
            {
                MessageBox.Show("As senhas digitadas não correspondem", "Senha inválida");
            }
        }

        private void btnExibeOcultaSenha_Click(object sender, EventArgs e)
        {
            if (txtCadastraSenha.PasswordChar == '*')
            {
                txtCadastraSenha.PasswordChar = '\0';
                txtConfirmaSenha.PasswordChar = '\0';
                btnExibeOcultaSenha.Text = "Oculta Senha";
            }
            else
            {
                txtCadastraSenha.PasswordChar = '*';
                txtConfirmaSenha.PasswordChar = '*';
                btnExibeOcultaSenha.Text = "Exibe Senha";
            }
        }

        private void CadastraUser_Load(object sender, EventArgs e)
        {

        }
    }
}
