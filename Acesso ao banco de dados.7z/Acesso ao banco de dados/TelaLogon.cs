﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Acesso_ao_banco_de_dados
{
    public partial class TelaLogon : Form
    {
        public TelaLogon()
        {
            InitializeComponent();
        }
        public string sql;

        //Criar variavel global para armazenar senha consultada do úsuario:
        string senhaUser = string.Empty;

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TelaLogon_Load(object sender, EventArgs e)
        {

        }

        private void btnLogon_Click(object sender, EventArgs e)
        {
            Criptografia cripto = new Criptografia();

            //Consultar senha do usuário 
            string SQLsenha = "SELECT SENHA FROM tbl_logon WHERE Nome_user = '" + txtLogonUser.Text + "'";
            consultarSenha(SQLsenha);

            string senha = cripto.HashSHA256(txtLogonSenha.Text);

            StringComparer comparar = StringComparer.OrdinalIgnoreCase;

            if (comparar.Compare(senha, senhaUser) == 0)
            {
                this.Hide();
                Form1 Telainicial = new Form1();
                Telainicial.Show();
            }
            else {
                MessageBox.Show("senha incorreta ou Usuario invalido");

            }
        }


            //Metado para consultar a senha do usuario

            public void consultarSenha(string sql)
            {
                SqlConnection conn = new SqlConnection(Variaveis.strConn);
            try
            {
                conn.Open();
                SqlCommand consulta = new SqlCommand(sql, conn);
                SqlDataReader drDados = null;
                drDados = consulta.ExecuteReader();
                while (drDados.Read())

                {
                    senhaUser = (string)drDados["Senha"];

                }
                drDados.Close();
                conn.Close();
            }
            catch (SqlException s)
            {
                MessageBox.Show(s.Source.ToString());
            }
        }
    }
}
