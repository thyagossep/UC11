﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Acesso_ao_banco_de_dados
{

    
    public partial class ConsultaAutorEditora : Form
    {
        public string Consulta;
        public string IDEditora;
        public ConsultaAutorEditora()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ConsultaAutorEditora_Load(object sender, EventArgs e)
        {
            if (Variaveis.ConsultaSelecionada == "Autores")
            {
                tabCadastraAutoresEditoras.SelectedTab = tabAutores;
            }
            else if (Variaveis.ConsultaSelecionada == "Editoras")
            {
                tabCadastraAutoresEditoras.SelectedTab = tabEditoras;
            }
            else
            {
                MessageBox.Show("Consulta não selecionada!");
               
            }

            // Editora

            string consulta = "SELECT ID_Editora FROM tbl_editoras";
            CarregaComboBox carregaEditora = new CarregaComboBox();

            
            List<string> Editora = new List<string>();
            Editora.AddRange(carregaEditora.carregaComboBox(consulta, "ID_Editora"));

            
            cmbCodEditora.Items.AddRange(Editora.ToArray());

            // Autores --------------------------------------------------------------------

            consulta = "SELECT Nome_Autor, Sobrenome_Autor FROM tbl_Autores";
            CarregaComboBox carregaAutor = new CarregaComboBox();


            List<string> Autor = new List<string>();
            Autor.AddRange(carregaAutor.carregaComboBoxAutores(consulta, "Nome_Autor", "Sobrenome_Autor"));


            cmbListaAutores.Items.AddRange(Autor.ToArray());

            // Livros -------------------------------------------------------------------------

            consulta = "SELECT ID_Livro FROM tbl_Livro";
            CarregaComboBox carregaLivros = new CarregaComboBox();
            

            List<string> Livro = new List<string>();
            Livro.AddRange(carregaLivros.carregaComboBox(consulta, "ID_Livro"));
            

            cmbConsultaLivro.Items.AddRange(Livro.ToArray());
            var Livros = Livro.OrderBy(n => n).ToList();
        }

        private void txtNomeEditora_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void tabAutores_Click(object sender, EventArgs e)
        {

        }

        private void btnConsultaEditoras_Click(object sender, EventArgs e)
        {
            string consultaEditora = "SELECT Nome_Editora FROM tbl_Editoras WHERE ID_Editora = " + cmbCodEditora.SelectedItem;
            SqlConnection conn = new SqlConnection(Variaveis.strConn);
            try
            {
                conn.Open();
                SqlCommand comando = new SqlCommand(consultaEditora, conn);
                SqlDataReader drDados = null;
                drDados = comando.ExecuteReader();
                if (drDados.HasRows)
                {
                    while (drDados.Read())
                    {
                        IDEditora = drDados["Nome_Editora"].ToString();
                        txtNomeEditora.Text = IDEditora;
                    }
                }
                else
                {
                    MessageBox.Show("Código não encontrado");
                }
                drDados.Close();
                conn.Close();
            }
            catch (SqlException s)
            {
                MessageBox.Show(s.Source.ToString(), "Erro no Banco de Dados!!!");
            }
            catch
            {
                MessageBox.Show("Erro inesperado, melhor repensar suas escolhas de vida");
            }
        }

        private void cmbCodEditora_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbListaAutores_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void tabLivros_Click(object sender, EventArgs e)
        {
            
        }

        private void cmbConsultaLivro_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(Variaveis.strConn);
            try
            {
                conn.Open();

                SqlCommand comando = new SqlCommand(Consulta, conn);
                            
                SqlDataReader drDados = null;

                drDados = comando.ExecuteReader();
                if (drDados.HasRows)
                {
                    while (drDados.Read())
                    {

                        lblNomeLivro.Text = (string)drDados["Nome_Livro"];
                        lblISBN.Text = (string)drDados["ISBN"];
                        lblEditora.Text = (string)drDados["Nome_Editora"];
                        lblAutor.Text = (string)drDados["Nome_Autor"];
                    }
                }
                else
                {
                    MessageBox.Show("Código não encontrado");
                }
                drDados.Close();
                conn.Close();
            }
            catch (SqlException s)
            {
                MessageBox.Show(s.Source.ToString());
            }
        }
    }
}
