﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Classe referentes a criptografia de dados (adicionar a seção using)
using System.Security.Cryptography;

namespace Acesso_ao_banco_de_dados
{
    public class Criptografia
    {
        public string HashSHA256(string texto)
        {
            byte[] bytes = Encoding.ASCII.GetBytes(texto);
            SHA256Managed resultado = new SHA256Managed();
            byte[] hash = resultado.ComputeHash(bytes);

            StringBuilder strBuilder = new StringBuilder();
            foreach (byte item in hash )
            {
                strBuilder.Append(item.ToString("x2"));
            }
            return strBuilder.ToString();
        }
    }
}
