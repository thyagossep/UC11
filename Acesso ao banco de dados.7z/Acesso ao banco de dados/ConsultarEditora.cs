﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Acesso_ao_banco_de_dados
{
    public class ConsultarEditora
    {
        public void fazerConsulta(string consulta)
        {
            SqlConnection conn = new SqlConnection(Variaveis.strConn);
            try
            {
                // Abrir a conexão com o banco de dados:
                conn.Open();
                // Criar comando de consulta:
                SqlCommand comando = new SqlCommand(consulta, conn);
                // Criar o DataReader:
                SqlDataReader drDados = null;
                // Executar a consulta:
                drDados = comando.ExecuteReader();
                if (drDados.HasRows) // Verificar se há linhas retornadas 
                {
                    while (drDados.Read())
                    {
                        // Obter os resultados das colunas
                        Variaveis.CaixaTxtNomeEditora = (string)drDados["Nome_Editora"];

                    }
                }
                else
                {
                    MessageBox.Show("Código não encontrado");
                }
                drDados.Close();
                conn.Close();
            }
            catch (SqlException s)
            {
                MessageBox.Show(s.Source.ToString());
            }
        }
    }
}
