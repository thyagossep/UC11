﻿namespace Acesso_ao_banco_de_dados
{
    partial class ConsultaAutorEditora
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabCadastraAutoresEditoras = new System.Windows.Forms.TabControl();
            this.tabAutores = new System.Windows.Forms.TabPage();
            this.cmbListaAutores = new System.Windows.Forms.ComboBox();
            this.btnConsultarAutor = new System.Windows.Forms.Button();
            this.txtCodAutor = new System.Windows.Forms.TextBox();
            this.txtNomeAutor = new System.Windows.Forms.TextBox();
            this.txtSobrenomeAutor = new System.Windows.Forms.TextBox();
            this.lblListAutores = new System.Windows.Forms.Label();
            this.lblSobrenomeAutor = new System.Windows.Forms.Label();
            this.lblNomeAutor = new System.Windows.Forms.Label();
            this.lblCodAutor = new System.Windows.Forms.Label();
            this.tabEditoras = new System.Windows.Forms.TabPage();
            this.cmbCodEditora = new System.Windows.Forms.ComboBox();
            this.lblNomeEditora = new System.Windows.Forms.Label();
            this.lblCodEditora = new System.Windows.Forms.Label();
            this.btnConsultaEditoras = new System.Windows.Forms.Button();
            this.txtNomeEditora = new System.Windows.Forms.TextBox();
            this.tabLivros = new System.Windows.Forms.TabPage();
            this.lblNomeLivro = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblEditora = new System.Windows.Forms.Label();
            this.lblISBN = new System.Windows.Forms.Label();
            this.lblAutor = new System.Windows.Forms.Label();
            this.cmbConsultaLivro = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblConsultaLivro = new System.Windows.Forms.Label();
            this.tabCadastraAutoresEditoras.SuspendLayout();
            this.tabAutores.SuspendLayout();
            this.tabEditoras.SuspendLayout();
            this.tabLivros.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabCadastraAutoresEditoras
            // 
            this.tabCadastraAutoresEditoras.Controls.Add(this.tabAutores);
            this.tabCadastraAutoresEditoras.Controls.Add(this.tabEditoras);
            this.tabCadastraAutoresEditoras.Controls.Add(this.tabLivros);
            this.tabCadastraAutoresEditoras.Location = new System.Drawing.Point(12, 21);
            this.tabCadastraAutoresEditoras.Name = "tabCadastraAutoresEditoras";
            this.tabCadastraAutoresEditoras.SelectedIndex = 0;
            this.tabCadastraAutoresEditoras.Size = new System.Drawing.Size(682, 388);
            this.tabCadastraAutoresEditoras.TabIndex = 0;
            // 
            // tabAutores
            // 
            this.tabAutores.Controls.Add(this.cmbListaAutores);
            this.tabAutores.Controls.Add(this.btnConsultarAutor);
            this.tabAutores.Controls.Add(this.txtCodAutor);
            this.tabAutores.Controls.Add(this.txtNomeAutor);
            this.tabAutores.Controls.Add(this.txtSobrenomeAutor);
            this.tabAutores.Controls.Add(this.lblListAutores);
            this.tabAutores.Controls.Add(this.lblSobrenomeAutor);
            this.tabAutores.Controls.Add(this.lblNomeAutor);
            this.tabAutores.Controls.Add(this.lblCodAutor);
            this.tabAutores.Location = new System.Drawing.Point(4, 22);
            this.tabAutores.Name = "tabAutores";
            this.tabAutores.Padding = new System.Windows.Forms.Padding(3);
            this.tabAutores.Size = new System.Drawing.Size(674, 362);
            this.tabAutores.TabIndex = 0;
            this.tabAutores.Text = "Autores";
            this.tabAutores.UseVisualStyleBackColor = true;
            this.tabAutores.Click += new System.EventHandler(this.tabAutores_Click);
            // 
            // cmbListaAutores
            // 
            this.cmbListaAutores.FormattingEnabled = true;
            this.cmbListaAutores.Location = new System.Drawing.Point(178, 272);
            this.cmbListaAutores.Name = "cmbListaAutores";
            this.cmbListaAutores.Size = new System.Drawing.Size(181, 21);
            this.cmbListaAutores.TabIndex = 8;
            this.cmbListaAutores.SelectedIndexChanged += new System.EventHandler(this.cmbListaAutores_SelectedIndexChanged);
            // 
            // btnConsultarAutor
            // 
            this.btnConsultarAutor.Location = new System.Drawing.Point(193, 90);
            this.btnConsultarAutor.Name = "btnConsultarAutor";
            this.btnConsultarAutor.Size = new System.Drawing.Size(166, 43);
            this.btnConsultarAutor.TabIndex = 7;
            this.btnConsultarAutor.Text = "Consultar";
            this.btnConsultarAutor.UseVisualStyleBackColor = true;
            // 
            // txtCodAutor
            // 
            this.txtCodAutor.Location = new System.Drawing.Point(172, 36);
            this.txtCodAutor.Name = "txtCodAutor";
            this.txtCodAutor.Size = new System.Drawing.Size(149, 20);
            this.txtCodAutor.TabIndex = 6;
            // 
            // txtNomeAutor
            // 
            this.txtNomeAutor.Location = new System.Drawing.Point(129, 174);
            this.txtNomeAutor.Name = "txtNomeAutor";
            this.txtNomeAutor.Size = new System.Drawing.Size(149, 20);
            this.txtNomeAutor.TabIndex = 5;
            // 
            // txtSobrenomeAutor
            // 
            this.txtSobrenomeAutor.Location = new System.Drawing.Point(155, 218);
            this.txtSobrenomeAutor.Name = "txtSobrenomeAutor";
            this.txtSobrenomeAutor.Size = new System.Drawing.Size(149, 20);
            this.txtSobrenomeAutor.TabIndex = 4;
            // 
            // lblListAutores
            // 
            this.lblListAutores.AutoSize = true;
            this.lblListAutores.Location = new System.Drawing.Point(42, 272);
            this.lblListAutores.Name = "lblListAutores";
            this.lblListAutores.Size = new System.Drawing.Size(130, 13);
            this.lblListAutores.TabIndex = 3;
            this.lblListAutores.Text = "Lista Completa de Autores";
            // 
            // lblSobrenomeAutor
            // 
            this.lblSobrenomeAutor.AutoSize = true;
            this.lblSobrenomeAutor.Location = new System.Drawing.Point(42, 221);
            this.lblSobrenomeAutor.Name = "lblSobrenomeAutor";
            this.lblSobrenomeAutor.Size = new System.Drawing.Size(107, 13);
            this.lblSobrenomeAutor.TabIndex = 2;
            this.lblSobrenomeAutor.Text = "Sobrenome do Autor:";
            // 
            // lblNomeAutor
            // 
            this.lblNomeAutor.AutoSize = true;
            this.lblNomeAutor.Location = new System.Drawing.Point(42, 177);
            this.lblNomeAutor.Name = "lblNomeAutor";
            this.lblNomeAutor.Size = new System.Drawing.Size(81, 13);
            this.lblNomeAutor.TabIndex = 1;
            this.lblNomeAutor.Text = "Nome do Autor:";
            // 
            // lblCodAutor
            // 
            this.lblCodAutor.AutoSize = true;
            this.lblCodAutor.Location = new System.Drawing.Point(42, 39);
            this.lblCodAutor.Name = "lblCodAutor";
            this.lblCodAutor.Size = new System.Drawing.Size(124, 13);
            this.lblCodAutor.TabIndex = 0;
            this.lblCodAutor.Text = "Digite o código do Autor:";
            this.lblCodAutor.Click += new System.EventHandler(this.label1_Click);
            // 
            // tabEditoras
            // 
            this.tabEditoras.Controls.Add(this.cmbCodEditora);
            this.tabEditoras.Controls.Add(this.lblNomeEditora);
            this.tabEditoras.Controls.Add(this.lblCodEditora);
            this.tabEditoras.Controls.Add(this.btnConsultaEditoras);
            this.tabEditoras.Controls.Add(this.txtNomeEditora);
            this.tabEditoras.Location = new System.Drawing.Point(4, 22);
            this.tabEditoras.Name = "tabEditoras";
            this.tabEditoras.Padding = new System.Windows.Forms.Padding(3);
            this.tabEditoras.Size = new System.Drawing.Size(674, 362);
            this.tabEditoras.TabIndex = 1;
            this.tabEditoras.Text = "Editoras";
            this.tabEditoras.UseVisualStyleBackColor = true;
            // 
            // cmbCodEditora
            // 
            this.cmbCodEditora.FormattingEnabled = true;
            this.cmbCodEditora.Location = new System.Drawing.Point(194, 29);
            this.cmbCodEditora.Name = "cmbCodEditora";
            this.cmbCodEditora.Size = new System.Drawing.Size(179, 21);
            this.cmbCodEditora.TabIndex = 4;
            this.cmbCodEditora.SelectedIndexChanged += new System.EventHandler(this.cmbCodEditora_SelectedIndexChanged);
            // 
            // lblNomeEditora
            // 
            this.lblNomeEditora.AutoSize = true;
            this.lblNomeEditora.Location = new System.Drawing.Point(29, 226);
            this.lblNomeEditora.Name = "lblNomeEditora";
            this.lblNomeEditora.Size = new System.Drawing.Size(71, 13);
            this.lblNomeEditora.TabIndex = 3;
            this.lblNomeEditora.Text = "Nome Editora";
            // 
            // lblCodEditora
            // 
            this.lblCodEditora.AutoSize = true;
            this.lblCodEditora.Location = new System.Drawing.Point(29, 32);
            this.lblCodEditora.Name = "lblCodEditora";
            this.lblCodEditora.Size = new System.Drawing.Size(159, 13);
            this.lblCodEditora.TabIndex = 2;
            this.lblCodEditora.Text = "Selecione um código de editora:";
            // 
            // btnConsultaEditoras
            // 
            this.btnConsultaEditoras.Location = new System.Drawing.Point(130, 87);
            this.btnConsultaEditoras.Name = "btnConsultaEditoras";
            this.btnConsultaEditoras.Size = new System.Drawing.Size(129, 33);
            this.btnConsultaEditoras.TabIndex = 1;
            this.btnConsultaEditoras.Text = "Consulta";
            this.btnConsultaEditoras.UseVisualStyleBackColor = true;
            this.btnConsultaEditoras.Click += new System.EventHandler(this.btnConsultaEditoras_Click);
            // 
            // txtNomeEditora
            // 
            this.txtNomeEditora.Location = new System.Drawing.Point(106, 223);
            this.txtNomeEditora.Name = "txtNomeEditora";
            this.txtNomeEditora.Size = new System.Drawing.Size(262, 20);
            this.txtNomeEditora.TabIndex = 0;
            this.txtNomeEditora.TextChanged += new System.EventHandler(this.txtNomeEditora_TextChanged);
            // 
            // tabLivros
            // 
            this.tabLivros.Controls.Add(this.lblConsultaLivro);
            this.tabLivros.Controls.Add(this.label2);
            this.tabLivros.Controls.Add(this.label1);
            this.tabLivros.Controls.Add(this.lblNomeLivro);
            this.tabLivros.Controls.Add(this.label5);
            this.tabLivros.Controls.Add(this.label4);
            this.tabLivros.Controls.Add(this.lblEditora);
            this.tabLivros.Controls.Add(this.lblISBN);
            this.tabLivros.Controls.Add(this.lblAutor);
            this.tabLivros.Controls.Add(this.cmbConsultaLivro);
            this.tabLivros.Location = new System.Drawing.Point(4, 22);
            this.tabLivros.Name = "tabLivros";
            this.tabLivros.Padding = new System.Windows.Forms.Padding(3);
            this.tabLivros.Size = new System.Drawing.Size(674, 362);
            this.tabLivros.TabIndex = 2;
            this.tabLivros.Text = "Livros";
            this.tabLivros.UseVisualStyleBackColor = true;
            this.tabLivros.Click += new System.EventHandler(this.tabLivros_Click);
            // 
            // lblNomeLivro
            // 
            this.lblNomeLivro.AutoSize = true;
            this.lblNomeLivro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeLivro.Location = new System.Drawing.Point(45, 175);
            this.lblNomeLivro.Name = "lblNomeLivro";
            this.lblNomeLivro.Size = new System.Drawing.Size(101, 16);
            this.lblNomeLivro.TabIndex = 7;
            this.lblNomeLivro.Text = "Nome do Livro: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Silver;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(151, 273);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(221, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "                                                     ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Silver;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(151, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "                                ";
            // 
            // lblEditora
            // 
            this.lblEditora.AutoSize = true;
            this.lblEditora.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditora.Location = new System.Drawing.Point(45, 241);
            this.lblEditora.Name = "lblEditora";
            this.lblEditora.Size = new System.Drawing.Size(96, 16);
            this.lblEditora.TabIndex = 4;
            this.lblEditora.Text = "Nome Editora: ";
            // 
            // lblISBN
            // 
            this.lblISBN.AutoSize = true;
            this.lblISBN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblISBN.Location = new System.Drawing.Point(45, 208);
            this.lblISBN.Name = "lblISBN";
            this.lblISBN.Size = new System.Drawing.Size(44, 16);
            this.lblISBN.TabIndex = 3;
            this.lblISBN.Text = "ISBN: ";
            // 
            // lblAutor
            // 
            this.lblAutor.AutoSize = true;
            this.lblAutor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAutor.Location = new System.Drawing.Point(45, 273);
            this.lblAutor.Name = "lblAutor";
            this.lblAutor.Size = new System.Drawing.Size(103, 16);
            this.lblAutor.TabIndex = 2;
            this.lblAutor.Text = "Nome do Autor: ";
            // 
            // cmbConsultaLivro
            // 
            this.cmbConsultaLivro.FormattingEnabled = true;
            this.cmbConsultaLivro.Location = new System.Drawing.Point(251, 43);
            this.cmbConsultaLivro.Name = "cmbConsultaLivro";
            this.cmbConsultaLivro.Size = new System.Drawing.Size(121, 21);
            this.cmbConsultaLivro.TabIndex = 0;
            this.cmbConsultaLivro.SelectedIndexChanged += new System.EventHandler(this.cmbConsultaLivro_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Silver;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(151, 241);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "                                       ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Silver;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(151, 208);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "                                     ";
            // 
            // lblConsultaLivro
            // 
            this.lblConsultaLivro.AutoSize = true;
            this.lblConsultaLivro.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConsultaLivro.Location = new System.Drawing.Point(43, 43);
            this.lblConsultaLivro.Name = "lblConsultaLivro";
            this.lblConsultaLivro.Size = new System.Drawing.Size(162, 25);
            this.lblConsultaLivro.TabIndex = 10;
            this.lblConsultaLivro.Text = "Consulta Livro: ";
            // 
            // ConsultaAutorEditora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabCadastraAutoresEditoras);
            this.Name = "ConsultaAutorEditora";
            this.Text = "ConsultaAutorEditora";
            this.Load += new System.EventHandler(this.ConsultaAutorEditora_Load);
            this.tabCadastraAutoresEditoras.ResumeLayout(false);
            this.tabAutores.ResumeLayout(false);
            this.tabAutores.PerformLayout();
            this.tabEditoras.ResumeLayout(false);
            this.tabEditoras.PerformLayout();
            this.tabLivros.ResumeLayout(false);
            this.tabLivros.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabCadastraAutoresEditoras;
        private System.Windows.Forms.TabPage tabAutores;
        private System.Windows.Forms.TabPage tabEditoras;
        private System.Windows.Forms.Label lblListAutores;
        private System.Windows.Forms.Label lblSobrenomeAutor;
        private System.Windows.Forms.Label lblNomeAutor;
        private System.Windows.Forms.Label lblCodAutor;
        private System.Windows.Forms.Button btnConsultarAutor;
        private System.Windows.Forms.TextBox txtCodAutor;
        private System.Windows.Forms.TextBox txtNomeAutor;
        private System.Windows.Forms.TextBox txtSobrenomeAutor;
        private System.Windows.Forms.ComboBox cmbListaAutores;
        private System.Windows.Forms.ComboBox cmbCodEditora;
        private System.Windows.Forms.Label lblNomeEditora;
        private System.Windows.Forms.Label lblCodEditora;
        private System.Windows.Forms.Button btnConsultaEditoras;
        private System.Windows.Forms.TextBox txtNomeEditora;
        private System.Windows.Forms.TabPage tabLivros;
        private System.Windows.Forms.Label lblNomeLivro;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblEditora;
        private System.Windows.Forms.Label lblISBN;
        private System.Windows.Forms.Label lblAutor;
        private System.Windows.Forms.ComboBox cmbConsultaLivro;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblConsultaLivro;
    }
}