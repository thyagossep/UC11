CREATE DATABASE db_floricultura ON PRIMARY
(NAME = db_floricultura,

FILENAME = 'C:\SQL\db_floricultura.mdf',
SIZE = 6MB,
MAXSIZE = 15MB,
FILEGROWTH = 10%)
LOG ON (
NAME = db_floricultura_log,
FILENAME = 'C:\SQL\db_floricultura_log.ldf',
SIZE = 1MB, FILEGROWTH = 1MB)
GO

CREATE TABLE tbl_Cliente (
id_cliente SMALLINT PRIMARY KEY IDENTITY (100, 1),
RG VARCHAR (20) UNIQUE NOT NULL,
Nome_Cliente VARCHAR (30) NOT NULL,
Sobrenome_Cliente VARCHAR (50) NOT NULL,
Telefone VARCHAR (20) NOT NULL,
Endere�o VARCHAR (100)
);

CREATE TABLE tbl_Produto (
id_Produto SMALLINT PRIMARY KEY IDENTITY (100, 1),
Nome_Produto VARCHAR (50) NOT NULL,
tipo_Produto VARCHAR (30) NOT NULL,
Preco DECIMAL (10, 2) NOT NULL,
quantidade_estoque SMALLINT NOT NULL
);

CREATE TABLE tbl_Compra (
id_compra SMALLINT PRIMARY KEY IDENTITY (100 ,1),
id_cliente SMALLINT,
data_compra DATE NOT NULL,
nota_fiscal VARCHAR (30) NOT NULL,
codigo_transacao VARCHAR (50) NOT NULL,
CONSTRAINT fk_id_cliente FOREIGN KEY (id_cliente)
	REFERENCES tbl_Cliente (id_cliente) ON DELETE CASCADE,
);

CREATE TABLE tbl_itemsComp (
id_compra SMALLINT,
id_Produto SMALLINT,
qtd_comprada SMALLINT NOT NULL,
PRIMARY KEY (id_compra, id_Produto),
CONSTRAINT fk_id_compra FOREIGN KEY (id_compra)
	REFERENCES tbl_Compra (id_compra) ON DELETE CASCADE,
CONSTRAINT fk_id_Produto FOREIGN KEY (id_Produto)
	REFERENCES tbl_Produto (id_Produto),
);

INSERT INTO tbl_Cliente (RG, Nome_Cliente, Sobrenome_Cliente, telefone, Endere�o)
VALUES 
('123456789', 'Maria', 'Silva', '11999999999', 'Rua das Flores, 123'),
('987654321', 'Jo�o', 'Santos', '11888888888', 'Avenida das Plantas, 456'),
('456789123', 'Ana', 'Costa', '11777777777', 'Travessa dos Jardins, 789'),
('321654987', 'Carlos', 'Moraes', '11666666666', 'Pra�a das Orqu�deas, 111'),
('789123456', 'Paula', 'Oliveira', '11555555555', 'Rua dos Cravos, 222');

SELECT*FROM tbl_Cliente;

INSERT INTO tbl_Produto (Nome_Produto, tipo_Produto, preco, quantidade_estoque)
VALUES 
('Rosa Vermelha', 'Flor', 10.50, 100),
('Orqu�dea Branca', 'Flor', 25.00, 50),
('Vaso de Cer�mica', 'Vaso', 30.00, 30),
('Girassol', 'Flor', 15.00, 75),
('Tulipa Amarela', 'Flor', 20.00, 60),
('Samambaia', 'Planta', 12.00, 40),
('Cacto Pequeno', 'Planta', 8.00, 120),
('Vaso de Pl�stico', 'Vaso', 5.00, 200),
('Jardineira de Madeira', 'Vaso', 50.00, 15),
('Orqu�dea Azul', 'Flor', 35.00, 25);

SELECT*FROM tbl_Produto;

-- Compras do cliente Maria
INSERT INTO tbl_Compra (id_cliente, data_compra, nota_fiscal, codigo_transacao)
VALUES 
(100, '20240901', 'FL001', 'TH001'), 
(100, '20240915', 'FL002', 'TH002');  

-- Compras do cliente Jo�o
INSERT INTO tbl_Compra (id_cliente, data_compra, nota_fiscal, codigo_transacao)
VALUES 
(101, '20240905', 'FL003', 'TH003');

-- Compras do cliente Ana
INSERT INTO tbl_Compra (id_cliente, data_compra, nota_fiscal, codigo_transacao)
VALUES 
(102, '20240910', 'FL004', 'TH004'); 

-- Compras do cliente Carlos
INSERT INTO tbl_Compra (id_cliente, data_compra, nota_fiscal, codigo_transacao)
VALUES 
(103, '20240912', 'FL005', 'TH005');

-- Compras do cliente Paula
INSERT INTO tbl_Compra (id_cliente, data_compra, nota_fiscal, codigo_transacao)
VALUES  
(104, '20240920', 'FL006', 'TH006'), 
(104, '20240925', 'FL007', 'TH007'); 

SELECT*FROM tbl_Compra;

-- Itens da compra de Maria (TH001)
INSERT INTO tbl_itemsComp (id_compra, id_produto, qtd_comprada)
VALUES 
(100, 100, 12), 
(100, 101, 2);   

-- Itens da segunda compra de Maria (TH002)
INSERT INTO tbl_itemsComp (id_compra, id_produto, qtd_comprada)
VALUES 
(101, 103, 10), 
(101, 102, 1);   

-- Itens da compra de Jo�o (TH003)
INSERT INTO tbl_itemsComp (id_compra, id_produto, qtd_comprada)
VALUES 
(102, 104, 5), 
(102, 105, 2);   

-- Itens da compra de Ana (TH004)
INSERT INTO tbl_itemsComp(id_compra, id_produto, qtd_comprada)
VALUES 
(103, 107, 20); 

-- Itens da compra de Carlos (TH005)
INSERT INTO tbl_itemsComp (id_compra, id_produto, qtd_comprada)
VALUES 
(104, 108, 3);   

-- Itens da primeira compra de Paula (TH006)
INSERT INTO tbl_itemsComp (id_compra, id_produto, qtd_comprada)
VALUES 
(105, 106, 4),   
(105, 101, 1);   

-- Itens da segunda compra de Paula (TH007)
INSERT INTO tbl_itemsComp(id_compra, id_produto, qtd_comprada)
VALUES 
(106, 109, 2);


SELECT*FROM tbl_itemsComp;

---UPDATE
UPDATE tbl_Produto
SET quantidade_estoque = 95
WHERE id_Produto = 100;

SELECT*FROM tbl_Produto;


-- FUN��ES DE AGREGA��O
SELECT SUM(preco) AS total_vendas
FROM tbl_Produto;

SELECT COUNT(*) AS total_clientes
FROM tbl_Cliente;

SELECT AVG(qtd_comprada) AS media_vendas
FROM tbl_itemsComp;

SELECT MAX(preco) AS preco_maximo
FROM tbl_Produto;

SELECT MIN(preco) AS preco_minimo
FROM tbl_Produto;

--INNER JOIN (perguntar pro professor)
SELECT Nome_Cliente, tbl_Compra.nota_fiscal
FROM tbl_Compra
INNER JOIN tbl_Cliente ON tbl_Compra.id_cliente = tbl_Cliente.id_cliente;

--OUTER JOIN
SELECT Nome_Cliente, tbl_Compra.nota_fiscal
FROM tbl_Cliente
LEFT JOIN tbl_Compra ON tbl_Cliente.id_cliente = tbl_Compra.id_cliente;

--ALTER TABLE
ALTER TABLE tbl_Produto ADD descricao VARCHAR(100);
SELECT*FROM tbl_Produto;

--BETWEEN
SELECT Nome_Produto, quantidade_estoque FROM tbl_Produto
WHERE quantidade_estoque BETWEEN 50 AND 75;

--NOT LIKE E LIKE
SELECT Nome_Produto, tipo_Produto FROM tbl_Produto
WHERE tipo_Produto NOT LIKE 'Flor';

SELECT tipo_Produto FROM tbl_Produto
WHERE tipo_Produto LIKE 'Flor';

--DELETE FROM
DELETE FROM tbl_Cliente WHERE id_cliente = 101;
SELECT*FROM tbl_Cliente;

--TRUNCATE TABLE Produto;

--SUBQUERIES
-- Selecionar o nome dos produtos cujo pre�o � maior que a m�dia dos pre�os
SELECT Nome_Produto
FROM tbl_Produto
WHERE preco > (SELECT AVG(preco) FROM tbl_Produto);

--ORDER BY
-- todos os produtos ordenados por pre�o (crescente)
SELECT Nome_Produto, Preco FROM tbl_Produto
ORDER BY preco ASC;

-- todos os produtos ordenados por nome (decrescente)
SELECT Nome_Produto FROM tbl_Produto
ORDER BY Nome_Produto DESC;



