CREATE DATABASE db_floricultura ON PRIMARY
(NAME = db_floricultura,

FILENAME = 'C\SQL\db_florcultura.mdf',
SIZE = 6MB,
MAXSIZE = 15MB,
FILEGROWT = 10%)
LOG ON (
NAME = db_floricultura,
FILENAME = 'C:\SQL\db_floricultura_log.ldf',
SIZE = 1MB, FILEGROWT = 1MB)
GO

CREATE TABLE tbl_Cliente (
CPF VARCHAR (11) PRIMARY KEY NOT NULL,
Nome_Cliente VARCHAR (30) NOT NULL,
Sobrenome_Cliente VARCHAR (50) NOT NULL,
