-- Criar banco de dados a usar nas aulas para testes
CREATE DATABASE db_Biblioteca ON PRIMARY
(NAME = db_Biblioteca,
FILENAME = 'C:\sql\db_Biblioteca.mdf', 
SIZE = 6MB,
MAXSIZE = 15MB,
FILEGROWTH = 10%)
LOG ON (
NAME = db_Biblioteca_log,
FILENAME ='C:\sql\db_Bibliotec_log.ldf',
SIZE = 1MB, FILEGROWTH = 1MB)
GO

-- Consultar os bancos existentes no servidor
SELECT name
FROM master.sys.databases
ORDER BY name;

-- Outra forma: com procedimento armazenado interno
EXEC sp_databases;

--Escolher o banco padrao a usar: declara��o USE
USE db_Biblioteca;

--Verificar dados extras sobre o banco de dados
EXEC sp_helpdb db_Biblioteca;

--Comentario de uma linha
/* comentario
de
mutiplas
linhas
*/

--CRIAR TABELAS NO BANCO db_biblioteca
-- TABELA AUTORES
CREATE TABLE Autor (
IdAutor SMALLINT IDENTITY,
NomeAutor VARCHAR(30) NOT NULL,
SobrenomeAutor VARCHAR(60) NOT NULL,
CONSTRAINT pk_id_autor_ PRIMARY KEY (IdAutor)
);

-- Verificar se tabela foi criada corretamente
EXEC sp_help Autor;

--TABELA EDITORAS
CREATE TABLE Editora (
IdEditora SMALLINT PRIMARY KEY IDENTITY,
NomeEditora VARCHAR(50) NOT NULL
);

-- TABELA DE ASSUNTOS
CREATE TABLE Assunto (
IdAssunto TINYINT PRIMARY KEY IDENTITY,
NomeAssunto VARCHAR(30) NOT NULL
);

EXEC sp_help Assunto;

--TABELA LIVROS
CREATE TABLE Livro (
IdLivro SMALLINT PRIMARY KEY IDENTITY (100,1),
Nomelivro VARCHAR(70) NOT NULL,
ISBN13 CHAR(13) UNIQUE,
DataPub DATE,
Precolivro MONEY NOT NULL,
NumeroPaginas SMALLINT NOT NULL,
IdEditora SMALLINT NOT NULL,
IdAssunto TINYINT,
CONSTRAINT fk_id_editora FOREIGN KEY (IdEditora) REFERENCES Editora (IdEditora)
	ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT fk_id_assunto FOREIGN KEY (IdAssunto) REFERENCES Assunto (IdAssunto)
	ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT verifica_preco CHECK (Precolivro >= 0)
);


EXEC sp_help Livro;

-- CRIAR TABELA LIVROAUTOR
CREATE TABLE LivroAutor (
IdLivro SMALLINT NOT NULL,
IdAutor SMALLINT NOT NULL,
CONSTRAINT pk_id_livros_autor PRIMARY KEY (IdLivro, IdAutor),
CONSTRAINT fk_id_livros FOREIGN KEY (IdLivro) REFERENCES Livro (IdLivro)
	ON DELETE CASCADE ON UPDATE CASCADE, 
CONSTRAINT fk_id_autores FOREIGN KEY (IdAutor) REFERENCES Autor (IdAutor)
	ON DELETE CASCADE ON UPDATE CASCADE, 
);

EXEC sp_help LivroAutor;

--Verificar tabelas criadas
SELECT name FROM db_biblioteca.sys.tables;


--TABELA LIVROS
CREATE TABLE Livro (
IdLivro SMALLINT PRIMARY KEY IDENTITY (100,1),
Nomelivro VARCHAR(70) NOT NULL,
ISBN13 CHAR(13) UNIQUE,
DataPub DATE,
Precolivro MONEY NOT NULL,
NumeroPaginas SMALLINT NOT NULL,
IdEditora SMALLINT NOT NULL,
IdAssunto TINYINT,
CONSTRAINT fk_id_editora FOREIGN KEY (IdEditora) REFERENCES Editora (IdEditora)
	ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT fk_id_assunto FOREIGN KEY (IdAssunto) REFERENCES Assunto (IdAssunto)
	ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT verifica_preco CHECK (Precolivro >= 0)
);

EXEC sp_help Livro;

-- CRIAR TABELA LIVROAUTOR
CREATE TABLE LivroAutor (
IdLivro SMALLINT NOT NULL,
IdAutor SMALLINT NOT NULL,
CONSTRAINT pk_id_livros_autor PRIMARY KEY (IdLivro, IdAutor),
CONSTRAINT fk_id_livros FOREIGN KEY (IdLivro) REFERENCES Livro (IdLivro)
	ON DELETE CASCADE ON UPDATE CASCADE, 
CONSTRAINT fk_id_autores FOREIGN KEY (IdAutor) REFERENCES Autor (IdAutor)
	ON DELETE CASCADE ON UPDATE CASCADE, 
);

EXEC sp_help LivroAutor;

SELECT name FROM db_biblioteca.sys.tables;


--Inserir registros nas TABELAS
/*
Declara��o INSERT INTO

Sintaxe:
INSERT INTO tabela (conluna01, coluna2,...)
VALUES (valor1, valor2,...);
*/

--Exemplo: Cadastrar uma Editora
INSERT INTO Editora(nomeEditora)
VALUES ('Prentice Hall');

--Verificar se linha foi inserida na tabela:
SELECT * FROM Autor


-- CADASTRAR VARIOS EDITORAS DE UMA VEZ:
INSERT INTO Editora (NomeEditora)
VALUES
('O Reilly'),
('Aleph'), ('Microsoft Press'), ('Willey'), ('HarperCollins'), 
('�rica'), ('Novatec'), ('McGraw-Hill'), ('Apress'), ('Francisco Alves'), ('Sybex'),
('Globio'), ('Companhia das letras'), ('Morro Branco'), ('Penguin Books'), ('Martin Claret'),
('Record'), ('Springer'), ('Melhoramentos'), ('Oxford'), ('Taschen'), ('Ediouro'), ('Bookman');

--Cadastrar os Assuntos
INSERT INTO Assunto (NomeAssunto)
VALUES
('Fic��o Ci�ntifica'), ('Bot�nica'), ('Elet�nica'),
('Matem�tica'), ('Aventura'), ('Romance'),
('Finan�as'), ('Gastronomia'), ('Terror'), ('Administra��o'), 
('Inform�tica'), ('Suspense');

--Cadastrar um Autor
INSERT INTO Autor (NomeAutor, SobrenomeAutor)
VALUES ('Umberto', 'Eco');

INSERT INTO Autor (NomeAutor, SobrenomeAutor)
VALUES 
('Daniel', 'Barret'), ('Gerald', 'Carter'), ('Mark', 'Sobell'),
('William', 'Stanek'), ('Christine','Bresnahan'), ('William', 'Gibson'),
('James', 'Joyce'), ('John', 'Emsley'), ('Jos�', 'Saramago'), ('Richard', 'Silverman'), ('Robert', 'Byrnes'), 
('Jay', 'Ts'), ('Robert', 'Eckstein'), ('Paul', 'Horowitz'), ('Winfild', 'Hill'), ('Joel', 'Murach'), ('Paul', 'Scherz'), ('Simon', 'Monk'), ('Napoleon', 'Hill'), ('�talo', 'Calvino'),
('Machado', ' de Assis'), ('Oliver', 'Sacks'), ('Ray', 'Bradbury'), ('Walter', 'Isaacson'), ('Benjamin', 'Graham'), ('J�lio', 'Verne'),
('Marcelo', 'Gleiser'), ('Harri', 'Lorenzi'), ('Humphrey', 'Carpenter'), ('Isaac', 'Asimov'), ('Aldous', 'Huxley'), ('Arthur', 'Conan Doyle'), ('Blaise', 'Pascal'), ('Jostein', 'Garden'), 
('Stephen', 'Hawking'), ('Stephen', 'Jay Gould'), ('Neil', 'De Grasse Tyson'), ('Charles', 'Darwin'), ('Alan', 'Turing'), ('Arthur', 'C. Clarke');

--Verificar se linha foi inserida na tabela:
SELECT * FROM Autor

--Tabela de livros
INSERT INTO Livro (NomeLivro, ISBN13, DataPub, Precolivro, NumeroPaginas, idAssunto, IdEditora)
VALUES ('A arte da Eletr�nica', '9788582604342', '20170308', 176.71, 1160, 3, 24);

SELECT * FROM Livro

INSERT INTO Livro (NomeLivro, ISBN13, DataPub, Precolivro, NumeroPaginas, idAssunto, IdEditora)
VALUES 
('Vinte Mil L�guas Submarinas', '9788525404179', '18700101', 24.50, 448, 1, 11),
('O Investidor Inteligente', '9788580410669', '19490101', 79.90, 450, 7, 6);


--Inserir dados em lote
INSERT INTO Livro(NomeLivro, ISBN13, DataPub, PrecoLivro, NumeroPaginas, IdEditora, IdAssunto)
SELECT
	Nomelivro, ISBN13, DataPub, PrecoLivro, NumeroPaginas, IdEditora, IdAssunto
FROM OPENROWSET	(
	BULK 'C:\SQL\Livros.CSV',
	FORMATFILE = 'C:\SQL\Formato.xml',
	CODEPAGE = '65001', --UTF-8
	FIRSTROW = 2
) AS LivrosCSV;

INSERT INTO LivroAutor (IdLivro, IdAutor)
VALUES
(100,15), (100,16),
(103,27), (103,26),
(103,41), (104,24), 
(105,32), (106,20), 
(107,27), (108,21),
(109,22), (110,10),
(111,21), (112,5),
(113,10), (114,8),
(115,18), (115,19),
(116,31), (117,22);

SELECT * FROM LivroAutor;

--Verificar Final 
SELECT NomeLivro, NomeAutor, SobrenomeAutor
FROM Livro
INNER JOIN LivroAutor
ON Livro.IdLivro = LivroAutor.IdLivro
INNER JOIN Autor
ON Autor.IdAutor = LivroAutor.IdAutor 
ORDER BY NomeLivro;

INSERT INTO Assunto (NomeAssunto)
VALUES
('Biologia');

SELECT * FROM Assunto; 

INSERT INTO Editora (NomeEditora)
VALUES ('BestSeller'), ('Camelot Editora')

SELECT * FROM Editora;

INSERT INTO Livro (NomeLivro, ISBN13, DataPub, Precolivro, NumeroPaginas, idAssunto, IdEditora)
VALUES ('O Baudolino', '9788577990023', '20070831', '29.90', '602', '5', '26');

INSERT INTO Livro (NomeLivro, ISBN13, DataPub, Precolivro, NumeroPaginas, idAssunto, IdEditora)
VALUES ('A origem das esp�cies', '9786585168755', '20240320', '34.90', '416', '13', '26');

SELECT * FROM Autor;

INSERT INTO LivroAutor(IdLivro, IdAutor)
VALUES (120,1), (122,36);

SELECT * FROM LivroAutor;

INSERT INTO Autor (NomeAutor, SobrenomeAutor)
VALUES ('Sun', 'Tzu');

INSERT INTO Editora (NomeEditora)
VALUES ('Novo S�culo');

INSERT INTO Assunto (NomeAssunto)
VALUES ('Filosofia');

INSERT INTO Livro (NomeLivro, ISBN13, DataPub, Precolivro, NumeroPaginas, idAssunto, IdEditora)
VALUES ('A arte da guerra', '9788542805093', '20150520', '45.95', '158', '14', '27');

INSERT INTO Autor (NomeAutor, SobrenomeAutor)
VALUES ('Oliver', 'Bowden');

INSERT INTO Editora (NomeEditora)
VALUES ('Galera');

INSERT INTO Livro (NomeLivro, ISBN13, DataPub, Precolivro, NumeroPaginas, idAssunto, IdEditora)
VALUES ('Assasin`s Creed', '9788501091338', '20110629', '48.00', '378', '1', '28');

SELECT * FROM Livro;

INSERT INTO Autor (NomeAutor, SobrenomeAutor)
VALUES ('George', 'Orwell');

INSERT INTO Editora (NomeEditora)
VALUES ('Companhia das Letras');

INSERT INTO Assunto (NomeAssunto)
VALUES ('Pol�tica');

INSERT INTO Livro (NomeLivro, ISBN13, DataPub, Precolivro, NumeroPaginas, idAssunto, IdEditora)
VALUES ('A Revolu��o dos Bichos', '9788535909555', '20070110', '14.09', '152', '15', '29');

SELECT * FROM LivroAutor;

INSERT INTO LivroAutor(IdLivro, IdAutor)
VALUES (124,79), (125,80), (126,81);

SELECT NomeLivro, NomeAutor, SobrenomeAutor
FROM Livro
INNER JOIN LivroAutor
ON Livro.IdLivro = LivroAutor.IdLivro
INNER JOIN Autor
ON Autor.IdAutor = LivroAutor.IdAutor 
ORDER BY NomeLivro;

