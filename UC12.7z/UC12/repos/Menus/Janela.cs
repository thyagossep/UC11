﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Menus
{
    public partial class Janela : Form
    {
        public Janela()
        {
            InitializeComponent();
        }

        private void Janela_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (Application.OpenForms.Count == 0)
            {
                //Fecha o programa se não houver mais janelas abertas
                Application.Exit();
            }
            else
            {
                //Loop pelos forms abertos
                foreach (Form formeAberto in Application.OpenForms)
                {
                    //Se form1 ainda estiver aberto
                    if (formeAberto is Form1);
                    {
                        formeAberto.Show();
                        break;
                    }

                }
            }
        }
    }
}
