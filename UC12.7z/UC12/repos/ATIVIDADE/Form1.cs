﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATIVIDADE
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMensagem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("SUCESSO", "CADASTRO");


            string fim;
            fim = (txtNome.Text + " " + txtSobrenome.Text);

            lblfim.Text = fim;
           
            string nome;
            nome = txtNome.Text;

            string sobrenome;
            sobrenome = txtSobrenome.Text;

            string cpf;
            cpf = txtCpf.Text;

            string endereco;
            endereco = txtEnd.Text;
        }

        private void lblfim_Click(object sender, EventArgs e)
        {

        }

        private void txtNome_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtSobrenome.Focus();
            }
        }

        private void txtSobrenome_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            { 
                txtCpf.Focus();           
            }
        }

        private void txtCpf_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtEnd.Focus(); 
            }
        }

        private void btnMensagem_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void txtEnd_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                btnMensagem_Click(sender, e);
            }
        }
    }
}
