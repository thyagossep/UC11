﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Investimentos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double capital, taxa; 
            int periodo;

            Console.WriteLine("Digite qual investimento inicial: ");
            capital = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Digite a taxa de juros: ");
            taxa = Convert.ToDouble(Console.ReadLine()) / 100;
            Console.WriteLine("Digite o tempo de investimento: ");
            periodo = Convert.ToInt32(Console.ReadLine()) * 12;

           
            double resultado = Math.Pow((1 + taxa), periodo);
            double mont = capital * resultado;
            Console.WriteLine(mont);

            Console.ReadLine();

        }
    }
}
