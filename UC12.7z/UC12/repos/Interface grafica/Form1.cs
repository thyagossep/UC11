﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interface_grafica
{
    public partial class IbTexto : Form
    {
        public IbTexto()
        {
            InitializeComponent();
        }

        private void botton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Interface Gráfica", "Aplicação 01");
            txtMensagem.Text = "Thyago Soares";

            string texto;
            texto = txtMensagem.Text;
            MessageBox.Show(texto, "Seu texto");

            /*
            string text;
            text = txtMensagem.Text;
            MessageBox.Show(texto, "Mensagem1");
            */
        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }

        private void txtMensagem_Click(object sender, EventArgs e)
        {

        }
    }
}
