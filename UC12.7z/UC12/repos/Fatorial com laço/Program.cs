﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fatorial_com_laço
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            int n, fat, cont;
            n = 0;
            fat = 1;
            Console.Write("Digite o número que deseja fatorar: ");
            n = int.Parse(Console.ReadLine());

            if (n < 0) 
            {
                Console.WriteLine("Número escolhido é invalido!!");
            }
            else if((n == 0 ) || (n == 1)) 
            {
                Console.WriteLine(fat.ToString());
            }
            else 
            {
                for (int i = 1; i <= n; i++) 
                {
                    fat *= i; 
                }
                Console.Write(fat.ToString());
                Console.ReadLine();
            */

            //Exemplo: Array de 6 posições para números inteiros 
            int[] numlot = new int[6];

            //Preencher arrey na inicialização
            int[] num01 = new int[5] {4, 2, 6, 9, 10};

            //Outra forma de preencher na inicialização
            int[] num02 = {5, 6 , 7, 8, 9,10};

            //Acesssar Arrays
            int valor;
            valor = num01[2];
            Console.WriteLine("Item na posição 2 do array: {0}", num01[2]);
            Console.WriteLine("Item na posição 2 do array: {0}", valor);

            //Alterar conteúdo do array
            num01[2] = 19;
            Console.WriteLine("Item na posição 2 do array {0}", num01[2]);

            //Alterar elementos do array
            for(int i = 0; i < 5; i++) 
            {
                Console.WriteLine(num01[i]);
            }

            // Alterar pelos elemntos do array com foreach
            foreach(int item in num01)
            {
                Console.WriteLine(item.ToString());
            }
            Console.ReadLine();
        }
    }
}
