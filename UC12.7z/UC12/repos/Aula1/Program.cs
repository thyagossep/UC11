﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Declaração de variaveis
            int numero1;
            string meuNome;

            //Atribuir Valores
            numero1 = 160;
            bool a = true;
            int x = 20, y = 25, z = 30;

            /*
            //Exibir valores na tela (console)
            Console.WriteLine("Thyago Soares");
            Console.WriteLine(x.ToString());
            Console.WriteLine("Número: " + y.ToString());

            Console.WriteLine(x.ToString() + y.ToString());
            Console.WriteLine(x + y);
            */

            /*
            Declarar Constantes 
            const int num1 = 23;
            Console.WriteLine(num1);
            */

            /*
            //Conversão de Tipos (basicos)
            int i = 100;
            float f = 31.1f;
            double d = 53.20;
            bool b = true;

            Console.WriteLine(Convert.ToDouble(i).ToString());
            Console.WriteLine(Convert.ToDouble(f).ToString());
            Console.WriteLine(d); //Conversão implicita
            Console.WriteLine(d.ToString()); // Conversão explicita
            Console.WriteLine(Convert.ToInt32(d).ToString());

            Console.WriteLine("Booleano:{0}", b.ToString());

            double precoPrata = 5.21;
            int preco;
            preco = (int)precoPrata; //Conversão do tipo cast
            Console.BackgroundColor = ConsoleColor.Green;
            Console.BackgroundColor = ConsoleColor.Magenta;
            Console.WriteLine("Preço: {0}", preco);
            */

            string item;
            Console.Write("Digite o nome do item a a adquirir: ");
            item = Console.ReadLine();
            Console.WriteLine("item escolhido: {0}", item);


            Console.ReadLine();
        }
    }
}
