﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Caixa_delistas__RadioBUttons_e_imagems
{
    public partial class txtNome : Form
    {
        public txtNome()
        {
            InitializeComponent();
        }

        int flag = 0;

        private void txtNome_Load(object sender, EventArgs e)
        {

        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
           listNomes.Items.Add(textBox1.Text);  
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listNomes.Items.Clear();
        }

        private void btnApagarItem_Click(object sender, EventArgs e)
        {
            for (int i = listNomes.SelectedIndices.Count - 1; i >= 0; i--)
            {
                listNomes.Items.RemoveAt(listNomes.SelectedIndices[i]);
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
             MessageBox.Show("Nome Cadastrado", "Sucesso");
        }

        private void btnRemoverCaractere_Click(object sender, EventArgs e)
        {
            string texto = textBox1.Text;
            string textoRemovido = string.Empty;
            int posição = texto.Length - 1;
            textoRemovido = texto.Remove(posição, 1);
            textBox1.Text = textoRemovido;  
        }

        private void btnPreencher_Click(object sender, EventArgs e)
        {
            for (int i = 1; i <= 10; i++ )
            {
                cmbNumeros.Items.Add(i.ToString());
            }
        }

        private void cmbNumeros_SelectedIndexChanged(object sender, EventArgs e)
        {
            string num;
            num = cmbNumeros.Text;
            txtNumeros.Text = num;
        }

        private void btnAnimal_Click(object sender, EventArgs e)
        {
            string animal = String.Empty;
            if (radioGirafa.Checked == true)
                animal = "Girafa";
            else if (radioLeao.Checked == true)
                animal = "Leão";
            else if (radioTigre.Checked == true)
                animal = "Tigre";
            else
            {
                animal = "Burro";
                MessageBox.Show("Selecione um animal", "Erro de seleção");
            }

            string imagem = "C:\\imagem\\" + animal + ".jpg";
            picAnimal.ImageLocation = imagem;
            btnLimpaImagem.Enabled = true;
            btnDesmarcar.Enabled = true;
        }

        private void btnLimpaImagem_Click(object sender, EventArgs e)
        {
            picAnimal = null;   
            btnLimpaImagem.Enabled = false;
        }

        private void btnProcurarImagem_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            string caminhoImagem = openFileDialog1.FileName;
            picAnimal.ImageLocation = caminhoImagem;
        }

        private void btnDesmarcar_Click(object sender, EventArgs e)
        {
            radioGirafa.Checked = false;
            radioLeao.Checked = false;
            radioTigre.Checked = false;
            btnDesmarcar.Enabled = false;
        }
    }
}
