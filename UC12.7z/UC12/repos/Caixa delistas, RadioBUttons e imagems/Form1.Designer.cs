﻿namespace Caixa_delistas__RadioBUttons_e_imagems
{
    partial class txtNome
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblnome = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnAdicionar = new System.Windows.Forms.Button();
            this.btnRemoverCaractere = new System.Windows.Forms.Button();
            this.btnApagarItem = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.listNomes = new System.Windows.Forms.ListBox();
            this.btnPreencher = new System.Windows.Forms.Button();
            this.cmbNumeros = new System.Windows.Forms.ComboBox();
            this.lblNumeros = new System.Windows.Forms.Label();
            this.txtNumeros = new System.Windows.Forms.TextBox();
            this.btnAnimal = new System.Windows.Forms.Button();
            this.btnDesmarcar = new System.Windows.Forms.Button();
            this.btnProcurarImagem = new System.Windows.Forms.Button();
            this.gprAnimal = new System.Windows.Forms.GroupBox();
            this.radioLeao = new System.Windows.Forms.RadioButton();
            this.radioTigre = new System.Windows.Forms.RadioButton();
            this.radioGirafa = new System.Windows.Forms.RadioButton();
            this.btnLimpaImagem = new System.Windows.Forms.Button();
            this.picAnimal = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.gprAnimal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAnimal)).BeginInit();
            this.SuspendLayout();
            // 
            // lblnome
            // 
            this.lblnome.AutoSize = true;
            this.lblnome.Location = new System.Drawing.Point(31, 35);
            this.lblnome.Name = "lblnome";
            this.lblnome.Size = new System.Drawing.Size(86, 13);
            this.lblnome.TabIndex = 0;
            this.lblnome.Text = "Digite um nome: ";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(123, 32);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btnAdicionar
            // 
            this.btnAdicionar.Location = new System.Drawing.Point(123, 68);
            this.btnAdicionar.Name = "btnAdicionar";
            this.btnAdicionar.Size = new System.Drawing.Size(100, 39);
            this.btnAdicionar.TabIndex = 2;
            this.btnAdicionar.Text = "Adcionar";
            this.btnAdicionar.UseVisualStyleBackColor = true;
            this.btnAdicionar.Click += new System.EventHandler(this.btnAdicionar_Click);
            // 
            // btnRemoverCaractere
            // 
            this.btnRemoverCaractere.Location = new System.Drawing.Point(250, 24);
            this.btnRemoverCaractere.Name = "btnRemoverCaractere";
            this.btnRemoverCaractere.Size = new System.Drawing.Size(97, 41);
            this.btnRemoverCaractere.TabIndex = 3;
            this.btnRemoverCaractere.Text = "Apagar Último Caractere";
            this.btnRemoverCaractere.UseVisualStyleBackColor = true;
            this.btnRemoverCaractere.Click += new System.EventHandler(this.btnRemoverCaractere_Click);
            // 
            // btnApagarItem
            // 
            this.btnApagarItem.Location = new System.Drawing.Point(123, 382);
            this.btnApagarItem.Name = "btnApagarItem";
            this.btnApagarItem.Size = new System.Drawing.Size(100, 36);
            this.btnApagarItem.TabIndex = 4;
            this.btnApagarItem.Text = "Apagar Item";
            this.btnApagarItem.UseVisualStyleBackColor = true;
            this.btnApagarItem.Click += new System.EventHandler(this.btnApagarItem_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(123, 340);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(100, 36);
            this.btnLimpar.TabIndex = 5;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(279, 177);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(97, 42);
            this.btnVerificar.TabIndex = 6;
            this.btnVerificar.Text = "Verificar";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // listNomes
            // 
            this.listNomes.FormattingEnabled = true;
            this.listNomes.Location = new System.Drawing.Point(103, 125);
            this.listNomes.Name = "listNomes";
            this.listNomes.Size = new System.Drawing.Size(145, 199);
            this.listNomes.TabIndex = 7;
            // 
            // btnPreencher
            // 
            this.btnPreencher.Location = new System.Drawing.Point(496, 24);
            this.btnPreencher.Name = "btnPreencher";
            this.btnPreencher.Size = new System.Drawing.Size(97, 41);
            this.btnPreencher.TabIndex = 8;
            this.btnPreencher.Text = "Preencher ComboBox";
            this.btnPreencher.UseVisualStyleBackColor = true;
            this.btnPreencher.Click += new System.EventHandler(this.btnPreencher_Click);
            // 
            // cmbNumeros
            // 
            this.cmbNumeros.FormattingEnabled = true;
            this.cmbNumeros.Location = new System.Drawing.Point(485, 86);
            this.cmbNumeros.Name = "cmbNumeros";
            this.cmbNumeros.Size = new System.Drawing.Size(121, 21);
            this.cmbNumeros.TabIndex = 9;
            this.cmbNumeros.SelectedIndexChanged += new System.EventHandler(this.cmbNumeros_SelectedIndexChanged);
            // 
            // lblNumeros
            // 
            this.lblNumeros.AutoSize = true;
            this.lblNumeros.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeros.Location = new System.Drawing.Point(681, 24);
            this.lblNumeros.Name = "lblNumeros";
            this.lblNumeros.Size = new System.Drawing.Size(169, 16);
            this.lblNumeros.TabIndex = 10;
            this.lblNumeros.Text = "Números Selecionados";
            // 
            // txtNumeros
            // 
            this.txtNumeros.Location = new System.Drawing.Point(709, 59);
            this.txtNumeros.Name = "txtNumeros";
            this.txtNumeros.Size = new System.Drawing.Size(125, 20);
            this.txtNumeros.TabIndex = 11;
            // 
            // btnAnimal
            // 
            this.btnAnimal.Location = new System.Drawing.Point(727, 163);
            this.btnAnimal.Name = "btnAnimal";
            this.btnAnimal.Size = new System.Drawing.Size(105, 56);
            this.btnAnimal.TabIndex = 12;
            this.btnAnimal.Text = "Escolha Animal";
            this.btnAnimal.UseVisualStyleBackColor = true;
            this.btnAnimal.Click += new System.EventHandler(this.btnAnimal_Click);
            // 
            // btnDesmarcar
            // 
            this.btnDesmarcar.Location = new System.Drawing.Point(729, 242);
            this.btnDesmarcar.Name = "btnDesmarcar";
            this.btnDesmarcar.Size = new System.Drawing.Size(103, 56);
            this.btnDesmarcar.TabIndex = 13;
            this.btnDesmarcar.Text = "Desmarcar opções";
            this.btnDesmarcar.UseVisualStyleBackColor = true;
            this.btnDesmarcar.Click += new System.EventHandler(this.btnDesmarcar_Click);
            // 
            // btnProcurarImagem
            // 
            this.btnProcurarImagem.Location = new System.Drawing.Point(934, 111);
            this.btnProcurarImagem.Name = "btnProcurarImagem";
            this.btnProcurarImagem.Size = new System.Drawing.Size(110, 43);
            this.btnProcurarImagem.TabIndex = 14;
            this.btnProcurarImagem.Text = "Selecionar Imagem do PC";
            this.btnProcurarImagem.UseVisualStyleBackColor = true;
            this.btnProcurarImagem.Click += new System.EventHandler(this.btnProcurarImagem_Click);
            // 
            // gprAnimal
            // 
            this.gprAnimal.Controls.Add(this.radioGirafa);
            this.gprAnimal.Controls.Add(this.radioTigre);
            this.gprAnimal.Controls.Add(this.radioLeao);
            this.gprAnimal.Location = new System.Drawing.Point(485, 169);
            this.gprAnimal.Name = "gprAnimal";
            this.gprAnimal.Size = new System.Drawing.Size(200, 155);
            this.gprAnimal.TabIndex = 15;
            this.gprAnimal.TabStop = false;
            this.gprAnimal.Text = "Animal";
            // 
            // radioLeao
            // 
            this.radioLeao.AutoSize = true;
            this.radioLeao.Location = new System.Drawing.Point(49, 66);
            this.radioLeao.Name = "radioLeao";
            this.radioLeao.Size = new System.Drawing.Size(49, 17);
            this.radioLeao.TabIndex = 0;
            this.radioLeao.TabStop = true;
            this.radioLeao.Text = "Leão";
            this.radioLeao.UseVisualStyleBackColor = true;
            // 
            // radioTigre
            // 
            this.radioTigre.AutoSize = true;
            this.radioTigre.Location = new System.Drawing.Point(49, 112);
            this.radioTigre.Name = "radioTigre";
            this.radioTigre.Size = new System.Drawing.Size(49, 17);
            this.radioTigre.TabIndex = 1;
            this.radioTigre.TabStop = true;
            this.radioTigre.Text = "Tigre";
            this.radioTigre.UseVisualStyleBackColor = true;
            // 
            // radioGirafa
            // 
            this.radioGirafa.AutoSize = true;
            this.radioGirafa.Location = new System.Drawing.Point(49, 21);
            this.radioGirafa.Name = "radioGirafa";
            this.radioGirafa.Size = new System.Drawing.Size(53, 17);
            this.radioGirafa.TabIndex = 2;
            this.radioGirafa.TabStop = true;
            this.radioGirafa.Text = "Girafa";
            this.radioGirafa.UseVisualStyleBackColor = true;
            // 
            // btnLimpaImagem
            // 
            this.btnLimpaImagem.Location = new System.Drawing.Point(1083, 111);
            this.btnLimpaImagem.Name = "btnLimpaImagem";
            this.btnLimpaImagem.Size = new System.Drawing.Size(113, 43);
            this.btnLimpaImagem.TabIndex = 16;
            this.btnLimpaImagem.Text = "Limpar Imagem";
            this.btnLimpaImagem.UseVisualStyleBackColor = true;
            this.btnLimpaImagem.Click += new System.EventHandler(this.btnLimpaImagem_Click);
            // 
            // picAnimal
            // 
            this.picAnimal.Location = new System.Drawing.Point(906, 202);
            this.picAnimal.Name = "picAnimal";
            this.picAnimal.Size = new System.Drawing.Size(244, 154);
            this.picAnimal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picAnimal.TabIndex = 17;
            this.picAnimal.TabStop = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "Imagens|*.jpg";
            // 
            // txtNome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1268, 450);
            this.Controls.Add(this.picAnimal);
            this.Controls.Add(this.btnLimpaImagem);
            this.Controls.Add(this.gprAnimal);
            this.Controls.Add(this.btnProcurarImagem);
            this.Controls.Add(this.btnDesmarcar);
            this.Controls.Add(this.btnAnimal);
            this.Controls.Add(this.txtNumeros);
            this.Controls.Add(this.lblNumeros);
            this.Controls.Add(this.cmbNumeros);
            this.Controls.Add(this.btnPreencher);
            this.Controls.Add(this.listNomes);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnApagarItem);
            this.Controls.Add(this.btnRemoverCaractere);
            this.Controls.Add(this.btnAdicionar);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblnome);
            this.Name = "txtNome";
            this.Text = "Caixas de Listas, Botões de Radio e imagens";
            this.Load += new System.EventHandler(this.txtNome_Load);
            this.gprAnimal.ResumeLayout(false);
            this.gprAnimal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAnimal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblnome;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnAdicionar;
        private System.Windows.Forms.Button btnRemoverCaractere;
        private System.Windows.Forms.Button btnApagarItem;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.ListBox listNomes;
        private System.Windows.Forms.Button btnPreencher;
        private System.Windows.Forms.ComboBox cmbNumeros;
        private System.Windows.Forms.Label lblNumeros;
        private System.Windows.Forms.TextBox txtNumeros;
        private System.Windows.Forms.Button btnAnimal;
        private System.Windows.Forms.Button btnDesmarcar;
        private System.Windows.Forms.Button btnProcurarImagem;
        private System.Windows.Forms.GroupBox gprAnimal;
        private System.Windows.Forms.RadioButton radioGirafa;
        private System.Windows.Forms.RadioButton radioTigre;
        private System.Windows.Forms.RadioButton radioLeao;
        private System.Windows.Forms.Button btnLimpaImagem;
        private System.Windows.Forms.PictureBox picAnimal;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

