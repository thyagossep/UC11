﻿namespace Acesso_ao_banco_de_dados
{
    partial class CadastraUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeUsuario = new System.Windows.Forms.Label();
            this.lblSenha = new System.Windows.Forms.Label();
            this.lblRepeteSenha = new System.Windows.Forms.Label();
            this.txtCadastraSenha = new System.Windows.Forms.TextBox();
            this.txtCadastraNome = new System.Windows.Forms.TextBox();
            this.txtConfirmaSenha = new System.Windows.Forms.TextBox();
            this.btnCadastrarUser = new System.Windows.Forms.Button();
            this.btnExibeOcultaSenha = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNomeUsuario
            // 
            this.lblNomeUsuario.AutoSize = true;
            this.lblNomeUsuario.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeUsuario.Location = new System.Drawing.Point(89, 73);
            this.lblNomeUsuario.Name = "lblNomeUsuario";
            this.lblNomeUsuario.Size = new System.Drawing.Size(247, 19);
            this.lblNomeUsuario.TabIndex = 0;
            this.lblNomeUsuario.Text = "Digite o nome de usuário desejado:";
            // 
            // lblSenha
            // 
            this.lblSenha.AutoSize = true;
            this.lblSenha.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSenha.Location = new System.Drawing.Point(89, 149);
            this.lblSenha.Name = "lblSenha";
            this.lblSenha.Size = new System.Drawing.Size(171, 19);
            this.lblSenha.TabIndex = 1;
            this.lblSenha.Text = "Digite a senha desejada:";
            // 
            // lblRepeteSenha
            // 
            this.lblRepeteSenha.AutoSize = true;
            this.lblRepeteSenha.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRepeteSenha.Location = new System.Drawing.Point(89, 232);
            this.lblRepeteSenha.Name = "lblRepeteSenha";
            this.lblRepeteSenha.Size = new System.Drawing.Size(215, 19);
            this.lblRepeteSenha.TabIndex = 2;
            this.lblRepeteSenha.Text = "Repita a senha para confirmar:";
            // 
            // txtCadastraSenha
            // 
            this.txtCadastraSenha.Location = new System.Drawing.Point(104, 181);
            this.txtCadastraSenha.Name = "txtCadastraSenha";
            this.txtCadastraSenha.Size = new System.Drawing.Size(246, 20);
            this.txtCadastraSenha.TabIndex = 3;
            // 
            // txtCadastraNome
            // 
            this.txtCadastraNome.Location = new System.Drawing.Point(104, 106);
            this.txtCadastraNome.Name = "txtCadastraNome";
            this.txtCadastraNome.Size = new System.Drawing.Size(246, 20);
            this.txtCadastraNome.TabIndex = 4;
            // 
            // txtConfirmaSenha
            // 
            this.txtConfirmaSenha.Location = new System.Drawing.Point(104, 266);
            this.txtConfirmaSenha.Name = "txtConfirmaSenha";
            this.txtConfirmaSenha.Size = new System.Drawing.Size(246, 20);
            this.txtConfirmaSenha.TabIndex = 5;
            // 
            // btnCadastrarUser
            // 
            this.btnCadastrarUser.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrarUser.Location = new System.Drawing.Point(146, 334);
            this.btnCadastrarUser.Name = "btnCadastrarUser";
            this.btnCadastrarUser.Size = new System.Drawing.Size(149, 53);
            this.btnCadastrarUser.TabIndex = 6;
            this.btnCadastrarUser.Text = "Cadastrar Usuário";
            this.btnCadastrarUser.UseVisualStyleBackColor = true;
            // 
            // btnExibeOcultaSenha
            // 
            this.btnExibeOcultaSenha.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExibeOcultaSenha.Location = new System.Drawing.Point(386, 161);
            this.btnExibeOcultaSenha.Name = "btnExibeOcultaSenha";
            this.btnExibeOcultaSenha.Size = new System.Drawing.Size(150, 59);
            this.btnExibeOcultaSenha.TabIndex = 7;
            this.btnExibeOcultaSenha.Text = "Exibir Senha";
            this.btnExibeOcultaSenha.UseVisualStyleBackColor = true;
            // 
            // CadastraUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(573, 464);
            this.Controls.Add(this.btnExibeOcultaSenha);
            this.Controls.Add(this.btnCadastrarUser);
            this.Controls.Add(this.txtConfirmaSenha);
            this.Controls.Add(this.txtCadastraNome);
            this.Controls.Add(this.txtCadastraSenha);
            this.Controls.Add(this.lblRepeteSenha);
            this.Controls.Add(this.lblSenha);
            this.Controls.Add(this.lblNomeUsuario);
            this.Name = "CadastraUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CadastraUser";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeUsuario;
        private System.Windows.Forms.Label lblSenha;
        private System.Windows.Forms.Label lblRepeteSenha;
        private System.Windows.Forms.TextBox txtCadastraSenha;
        private System.Windows.Forms.TextBox txtCadastraNome;
        private System.Windows.Forms.TextBox txtConfirmaSenha;
        private System.Windows.Forms.Button btnCadastrarUser;
        private System.Windows.Forms.Button btnExibeOcultaSenha;
    }
}