﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Acesso_ao_banco_de_dados
{
    public partial class Form1 : Form
    {
        public string consulta;
        public string sql;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Carrega Combobox com método da classe CarregaComboBox e listas:
            string Consulta = "SELECT Nome_Livro FROM tbl_livro";
            CarregaComboBox carregaLivros =  new CarregaComboBox();

            // Criar objeto de lista para armazenar os dados dos livros:
            List<string> Livros = new List<string>();
            Livros.AddRange(carregaLivros.carregaComboBox(Consulta, "Nome_Livro"));

            // Copia dados da lista para o combobox:
            cmbLivros.Items.AddRange(Livros.ToArray());
        }
    }
}
