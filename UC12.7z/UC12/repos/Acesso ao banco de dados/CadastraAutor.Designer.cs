﻿namespace Acesso_ao_banco_de_dados
{
    partial class CadastraAutor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblNomeAutor = new System.Windows.Forms.Label();
            this.lblSobrenomeAutor = new System.Windows.Forms.Label();
            this.txtNomeAutor = new System.Windows.Forms.TextBox();
            this.txtSobrenomeAutor = new System.Windows.Forms.TextBox();
            this.btnCadastrarAutor = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(543, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Preencha os campos abaico e clique em \"Cadastrar\" para inserir um novo autor";
            // 
            // lblNomeAutor
            // 
            this.lblNomeAutor.AutoSize = true;
            this.lblNomeAutor.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeAutor.Location = new System.Drawing.Point(62, 109);
            this.lblNomeAutor.Name = "lblNomeAutor";
            this.lblNomeAutor.Size = new System.Drawing.Size(107, 17);
            this.lblNomeAutor.TabIndex = 1;
            this.lblNomeAutor.Text = "Nome do Autor:";
            // 
            // lblSobrenomeAutor
            // 
            this.lblSobrenomeAutor.AutoSize = true;
            this.lblSobrenomeAutor.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSobrenomeAutor.Location = new System.Drawing.Point(62, 181);
            this.lblSobrenomeAutor.Name = "lblSobrenomeAutor";
            this.lblSobrenomeAutor.Size = new System.Drawing.Size(140, 17);
            this.lblSobrenomeAutor.TabIndex = 2;
            this.lblSobrenomeAutor.Text = "Sobrenome do Autor:";
            // 
            // txtNomeAutor
            // 
            this.txtNomeAutor.Location = new System.Drawing.Point(222, 106);
            this.txtNomeAutor.Name = "txtNomeAutor";
            this.txtNomeAutor.Size = new System.Drawing.Size(171, 20);
            this.txtNomeAutor.TabIndex = 3;
            // 
            // txtSobrenomeAutor
            // 
            this.txtSobrenomeAutor.Location = new System.Drawing.Point(222, 181);
            this.txtSobrenomeAutor.Name = "txtSobrenomeAutor";
            this.txtSobrenomeAutor.Size = new System.Drawing.Size(171, 20);
            this.txtSobrenomeAutor.TabIndex = 4;
            // 
            // btnCadastrarAutor
            // 
            this.btnCadastrarAutor.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrarAutor.Location = new System.Drawing.Point(164, 242);
            this.btnCadastrarAutor.Name = "btnCadastrarAutor";
            this.btnCadastrarAutor.Size = new System.Drawing.Size(147, 68);
            this.btnCadastrarAutor.TabIndex = 5;
            this.btnCadastrarAutor.Text = "Cadastrar Autor";
            this.btnCadastrarAutor.UseVisualStyleBackColor = true;
            // 
            // CadastraAutor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCadastrarAutor);
            this.Controls.Add(this.txtSobrenomeAutor);
            this.Controls.Add(this.txtNomeAutor);
            this.Controls.Add(this.lblSobrenomeAutor);
            this.Controls.Add(this.lblNomeAutor);
            this.Controls.Add(this.label1);
            this.Name = "CadastraAutor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CadastraAutor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblNomeAutor;
        private System.Windows.Forms.Label lblSobrenomeAutor;
        private System.Windows.Forms.TextBox txtNomeAutor;
        private System.Windows.Forms.TextBox txtSobrenomeAutor;
        private System.Windows.Forms.Button btnCadastrarAutor;
    }
}