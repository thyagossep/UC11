﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Acesso_ao_banco_de_dados
{
     class ConsultarLivros
    {
        public void fazerconsulta(string consulta)
        {
            SqlConnection conn = new SqlConnection(Variaveis.strConn);
            try
            {
                conn.Open();

                SqlCommand comando = new SqlCommand(consulta, conn);

                SqlDataReader drDados = null;

                drDados = comando.ExecuteReader();
                if(drDados.HasRows)
                {
                    while (drDados.Read())
                    {
                        Variaveis.CaixaTxtNomeLivro = (string)drDados["Nome_Livro"];
                        Variaveis.CaixaTxtNomeAutor = (string)drDados["Nome_Autor"];

                        Variaveis.CaixaTxtPrecoLivro = string.Format("{0:0.00}", drDados["Preco_Livro"]);
                        Variaveis.CaixaTxtDataPub = (DateTime)drDados["Data_Pub"];
                    }
                }
                else
                {
                    MessageBox.Show("Código não encontrado");
                }
                drDados.Close();
                conn.Close();
            }
            catch (SqlException s) 
            {
                MessageBox.Show(s.Source.ToString());
            }
        }
    }
}
