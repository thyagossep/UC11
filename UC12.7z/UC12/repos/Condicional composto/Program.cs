﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;

namespace Condicional_composto
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            string name;
            int idade;
            int aposent = 65;

            Console.WriteLine("Qual seu nome: ");
            name = Console.ReadLine();

            Console.WriteLine("Qual sua idade: ");
             idade = Convert.ToInt32(Console.ReadLine());

            int resultado = aposent - idade;

            if (resultado != aposent) 
            {
                Console.WriteLine(name + " ainda faltam " + resultado + " anos para você se aposentar !!");
            }
            else
            {
                Console.WriteLine("Você já deve estar aposentado!!"); 
            }

            // Condicional encadeado

            int diasemana;
            string nome;

            Console.Write("Digite o dia da semana, de 1 a 7: ");
            diasemana = Int32.Parse(Console.ReadLine());

            if (diasemana == 1) 
            {
                nome = "Domingo";            
            }
            else if (diasemana == 2) 
            {
                nome = "Segunda-Feira";
            }
            else if (diasemana == 3)
            {
                nome = "Terça-Feira";
            }
            else if (diasemana == 4)
            {
                nome = "Quarta-Feira";
            }
            else if (diasemana == 5)
            {
                nome = "Quinta-Feira";
            }
            else if (diasemana == 6)
            {
                nome = "Sexta-Feira";
            }
            else if (diasemana == 7)
            {
                nome = "Sabádo";
            }
            else
            {
                nome = "Dia da semana não existente!!";

            Console.WriteLine("O dia da semana escolhido foi : {0}", nome);
                */

            float n1, n2, n3, n4, media;

            Console.Write("Digite a nota: ");
            n1 = float.Parse(Console.ReadLine());

            Console.Write("Digite a nota: ");
            n2 = float.Parse(Console.ReadLine());

            Console.Write("Digite a nota: ");
            n3 = float.Parse(Console.ReadLine());

            Console.Write("Digite a nota: ");
            n4 = float.Parse(Console.ReadLine());

            media = (n1 + n2 + n3 + n4) / 4;

            if (media >= 7) 
            {
                Console.Write("Aluno Aprovado!!");
            }
            else if (media >= 5)
            {
                Console.Write("Aluno de Recuperação!!");
            }
            else if (media < 7)
            {
                Console.Write("Aluno de Reprovado!!");
            }



            Console.ReadLine();
        }
    }
}
