﻿namespace Combo.Box
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbAnimais = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bntGerarNovaLista = new System.Windows.Forms.Button();
            this.txtItens = new System.Windows.Forms.TextBox();
            this.btnAdicionaItem = new System.Windows.Forms.Button();
            this.listAnimais = new System.Windows.Forms.ListBox();
            this.btnSelecionarTudo = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnClassificar = new System.Windows.Forms.Button();
            this.btndeselecionar = new System.Windows.Forms.Button();
            this.digiteNumero = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmbAnimais
            // 
            this.cmbAnimais.FormattingEnabled = true;
            this.cmbAnimais.Location = new System.Drawing.Point(54, 78);
            this.cmbAnimais.Name = "cmbAnimais";
            this.cmbAnimais.Size = new System.Drawing.Size(204, 21);
            this.cmbAnimais.TabIndex = 0;
            this.cmbAnimais.SelectedIndexChanged += new System.EventHandler(this.cmbAnimais_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(50, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(315, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Selecione Itens para adicionar ao ListBox";
            // 
            // bntGerarNovaLista
            // 
            this.bntGerarNovaLista.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntGerarNovaLista.Location = new System.Drawing.Point(84, 120);
            this.bntGerarNovaLista.Name = "bntGerarNovaLista";
            this.bntGerarNovaLista.Size = new System.Drawing.Size(140, 57);
            this.bntGerarNovaLista.TabIndex = 2;
            this.bntGerarNovaLista.Text = "Gerar Nova Listagem";
            this.bntGerarNovaLista.UseVisualStyleBackColor = true;
            this.bntGerarNovaLista.Click += new System.EventHandler(this.bntGerarNovaLista_Click);
            // 
            // txtItens
            // 
            this.txtItens.Location = new System.Drawing.Point(54, 212);
            this.txtItens.Name = "txtItens";
            this.txtItens.Size = new System.Drawing.Size(123, 20);
            this.txtItens.TabIndex = 3;
            // 
            // btnAdicionaItem
            // 
            this.btnAdicionaItem.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionaItem.Location = new System.Drawing.Point(231, 193);
            this.btnAdicionaItem.Name = "btnAdicionaItem";
            this.btnAdicionaItem.Size = new System.Drawing.Size(140, 57);
            this.btnAdicionaItem.TabIndex = 4;
            this.btnAdicionaItem.Text = "Adicionar item a ComboBox";
            this.btnAdicionaItem.UseVisualStyleBackColor = true;
            this.btnAdicionaItem.Click += new System.EventHandler(this.btnAdicionaItem_Click);
            // 
            // listAnimais
            // 
            this.listAnimais.FormattingEnabled = true;
            this.listAnimais.Location = new System.Drawing.Point(424, 33);
            this.listAnimais.Name = "listAnimais";
            this.listAnimais.Size = new System.Drawing.Size(209, 381);
            this.listAnimais.TabIndex = 5;
            // 
            // btnSelecionarTudo
            // 
            this.btnSelecionarTudo.Location = new System.Drawing.Point(452, 447);
            this.btnSelecionarTudo.Name = "btnSelecionarTudo";
            this.btnSelecionarTudo.Size = new System.Drawing.Size(154, 65);
            this.btnSelecionarTudo.TabIndex = 6;
            this.btnSelecionarTudo.Text = "Selecionar Tudo";
            this.btnSelecionarTudo.UseVisualStyleBackColor = true;
            this.btnSelecionarTudo.Click += new System.EventHandler(this.btnSelecionarTudo_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(674, 138);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(154, 63);
            this.button2.TabIndex = 7;
            this.button2.Text = "Remover Selecionados";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(674, 33);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(154, 63);
            this.btnlimpar.TabIndex = 8;
            this.btnlimpar.Text = "Limpar lista";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // btnClassificar
            // 
            this.btnClassificar.Location = new System.Drawing.Point(674, 236);
            this.btnClassificar.Name = "btnClassificar";
            this.btnClassificar.Size = new System.Drawing.Size(154, 64);
            this.btnClassificar.TabIndex = 9;
            this.btnClassificar.Text = "Classificar Lista";
            this.btnClassificar.UseVisualStyleBackColor = true;
            this.btnClassificar.Click += new System.EventHandler(this.btnClassificar_Click);
            // 
            // btndeselecionar
            // 
            this.btndeselecionar.Location = new System.Drawing.Point(674, 340);
            this.btndeselecionar.Name = "btndeselecionar";
            this.btndeselecionar.Size = new System.Drawing.Size(154, 64);
            this.btndeselecionar.TabIndex = 10;
            this.btndeselecionar.Text = "Deselecionar Lista";
            this.btndeselecionar.UseVisualStyleBackColor = true;
            this.btndeselecionar.Click += new System.EventHandler(this.btndeselecionar_Click);
            // 
            // digiteNumero
            // 
            this.digiteNumero.AutoSize = true;
            this.digiteNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.digiteNumero.Location = new System.Drawing.Point(1078, 78);
            this.digiteNumero.Name = "digiteNumero";
            this.digiteNumero.Size = new System.Drawing.Size(151, 18);
            this.digiteNumero.TabIndex = 11;
            this.digiteNumero.Text = "Digite um número: ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1415, 628);
            this.Controls.Add(this.digiteNumero);
            this.Controls.Add(this.btndeselecionar);
            this.Controls.Add(this.btnClassificar);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnSelecionarTudo);
            this.Controls.Add(this.listAnimais);
            this.Controls.Add(this.btnAdicionaItem);
            this.Controls.Add(this.txtItens);
            this.Controls.Add(this.bntGerarNovaLista);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbAnimais);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbAnimais;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bntGerarNovaLista;
        private System.Windows.Forms.TextBox txtItens;
        private System.Windows.Forms.Button btnAdicionaItem;
        private System.Windows.Forms.ListBox listAnimais;
        private System.Windows.Forms.Button btnSelecionarTudo;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnClassificar;
        private System.Windows.Forms.Button btndeselecionar;
        private System.Windows.Forms.Label digiteNumero;
    }
}

