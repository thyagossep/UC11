﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Combo.Box
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Flag para botão que adiciona items inseridos pelo úsuario
        int flag = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] bichos = new string[7] { "Gato", "Cão", "Papagaio", "Lontra", "Golfinho", "Foca", "Tatu" };
            cmbAnimais.Items.AddRange(bichos);
            cmbAnimais.Items.Add("Águia");
            cmbAnimais.Items.Add("Baleia");
            cmbAnimais.Items.Add("Tamanduá");
            cmbAnimais.Items.Add("Carpa");
        }

        private void bntGerarNovaLista_Click(object sender, EventArgs e)
        {
            cmbAnimais.Items.Clear();
            cmbAnimais.Text = string.Empty; //lIMPA ITEM QUE RESTA EXIBIDO NO COMBOBOX
            string[] lugares = new string[7] { "São Paulo", "Londres", "Montreal", "Roma", "Buenos Aires", "Berlim", "Amterdam" };
            cmbAnimais.Items.AddRange(lugares);
            flag = 0;
        }

        private void btnAdicionaItem_Click(object sender, EventArgs e)
        {
            if (flag == 0)
            {
                //Limpa lista para adicionar itens do usuário:
                cmbAnimais.Items.Clear();
                cmbAnimais.Text = String.Empty;

                //Sinal para indicar se a lista deve ser limpa ou não
                flag = 1;

                //Adiciona Item
                cmbAnimais.Items.Add(txtItens.Text);
                txtItens.Text = String.Empty;   
                txtItens.Focus();
            }
            else
            {
                cmbAnimais.Items.Add(txtItens.Text);
                txtItens.Text = String.Empty;
                txtItens.Focus();
            }

        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            //Limpar Tudo
            listAnimais.Items.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Remover item selecionado

            for (int i = listAnimais.SelectedIndices.Count - 1; i >= 0; i--)
            {
                listAnimais.Items.RemoveAt(listAnimais.SelectedIndices[i]);
            }
        }

        private void btnClassificar_Click(object sender, EventArgs e)
        {
            //Classificar em ordem alfabética

            listAnimais.Sorted = true;
        }

        private void btndeselecionar_Click(object sender, EventArgs e)
        {
            //Deselecionar Itens da list box de uma vez
            
            for(int x = 0; x < listAnimais.Items.Count; x++)
            {
                listAnimais.SetSelected(x, false);
            }
            // ou: listAnimais.ClearSelected
        }

        private void btnSelecionarTudo_Click(object sender, EventArgs e)
        {
            //Selecionar todos os itens da listBox de uma vez

            listAnimais.BeginUpdate();

            for (int x = 0; x < listAnimais.Items.Count; x++)
            {
                listAnimais.SetSelected(x, true);
            }
            listAnimais.EndUpdate();
        }

        private void cmbAnimais_SelectedIndexChanged(object sender, EventArgs e)
        {
            listAnimais.Items.Add(cmbAnimais.SelectedItem);
        }
    }
}
