﻿namespace CAdastros_Pet
{
    partial class EnderecoCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EnderecoCliente));
            this.lblEndereco = new System.Windows.Forms.Label();
            this.txtEndereco = new System.Windows.Forms.TextBox();
            this.lblBairro = new System.Windows.Forms.Label();
            this.txtBairro = new System.Windows.Forms.TextBox();
            this.lblCep = new System.Windows.Forms.Label();
            this.lblNumeroResidencia = new System.Windows.Forms.Label();
            this.txtNumeroResidencia = new System.Windows.Forms.TextBox();
            this.btnConcluirCadastro = new System.Windows.Forms.Button();
            this.maskCep = new System.Windows.Forms.MaskedTextBox();
            this.maskNascimento = new System.Windows.Forms.MaskedTextBox();
            this.maskCpf = new System.Windows.Forms.MaskedTextBox();
            this.lblNascimento = new System.Windows.Forms.Label();
            this.lblCPF = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtNumeroTel = new System.Windows.Forms.TextBox();
            this.txtSobrenome = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblNumeroTel = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblSobrenome = new System.Windows.Forms.Label();
            this.lblNomeCliente = new System.Windows.Forms.Label();
            this.lblCadastroCliente = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblEndereco
            // 
            this.lblEndereco.AutoSize = true;
            this.lblEndereco.BackColor = System.Drawing.Color.Transparent;
            this.lblEndereco.Font = new System.Drawing.Font("Arial Narrow", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEndereco.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblEndereco.Location = new System.Drawing.Point(683, 241);
            this.lblEndereco.Name = "lblEndereco";
            this.lblEndereco.Size = new System.Drawing.Size(88, 23);
            this.lblEndereco.TabIndex = 0;
            this.lblEndereco.Text = "Endereço:";
            // 
            // txtEndereco
            // 
            this.txtEndereco.Location = new System.Drawing.Point(777, 244);
            this.txtEndereco.Name = "txtEndereco";
            this.txtEndereco.Size = new System.Drawing.Size(256, 20);
            this.txtEndereco.TabIndex = 1;
            // 
            // lblBairro
            // 
            this.lblBairro.AutoSize = true;
            this.lblBairro.BackColor = System.Drawing.Color.Transparent;
            this.lblBairro.Font = new System.Drawing.Font("Arial Narrow", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBairro.Location = new System.Drawing.Point(710, 284);
            this.lblBairro.Name = "lblBairro";
            this.lblBairro.Size = new System.Drawing.Size(61, 23);
            this.lblBairro.TabIndex = 2;
            this.lblBairro.Text = "Bairro:";
            // 
            // txtBairro
            // 
            this.txtBairro.Location = new System.Drawing.Point(777, 287);
            this.txtBairro.Name = "txtBairro";
            this.txtBairro.Size = new System.Drawing.Size(256, 20);
            this.txtBairro.TabIndex = 3;
            // 
            // lblCep
            // 
            this.lblCep.AutoSize = true;
            this.lblCep.BackColor = System.Drawing.Color.Transparent;
            this.lblCep.Font = new System.Drawing.Font("Arial Narrow", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCep.Location = new System.Drawing.Point(725, 322);
            this.lblCep.Name = "lblCep";
            this.lblCep.Size = new System.Drawing.Size(46, 23);
            this.lblCep.TabIndex = 4;
            this.lblCep.Text = "CEP:";
            // 
            // lblNumeroResidencia
            // 
            this.lblNumeroResidencia.AutoSize = true;
            this.lblNumeroResidencia.BackColor = System.Drawing.Color.Transparent;
            this.lblNumeroResidencia.Font = new System.Drawing.Font("Arial Narrow", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeroResidencia.Location = new System.Drawing.Point(696, 351);
            this.lblNumeroResidencia.Name = "lblNumeroResidencia";
            this.lblNumeroResidencia.Size = new System.Drawing.Size(75, 23);
            this.lblNumeroResidencia.TabIndex = 6;
            this.lblNumeroResidencia.Text = "Número:";
            // 
            // txtNumeroResidencia
            // 
            this.txtNumeroResidencia.Location = new System.Drawing.Point(777, 356);
            this.txtNumeroResidencia.Name = "txtNumeroResidencia";
            this.txtNumeroResidencia.Size = new System.Drawing.Size(81, 20);
            this.txtNumeroResidencia.TabIndex = 7;
            // 
            // btnConcluirCadastro
            // 
            this.btnConcluirCadastro.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnConcluirCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConcluirCadastro.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnConcluirCadastro.Location = new System.Drawing.Point(813, 465);
            this.btnConcluirCadastro.Name = "btnConcluirCadastro";
            this.btnConcluirCadastro.Size = new System.Drawing.Size(123, 43);
            this.btnConcluirCadastro.TabIndex = 23;
            this.btnConcluirCadastro.Text = "Salvar";
            this.btnConcluirCadastro.UseVisualStyleBackColor = false;
            // 
            // maskCep
            // 
            this.maskCep.Location = new System.Drawing.Point(777, 322);
            this.maskCep.Mask = "00000-000";
            this.maskCep.Name = "maskCep";
            this.maskCep.Size = new System.Drawing.Size(107, 20);
            this.maskCep.TabIndex = 24;
            // 
            // maskNascimento
            // 
            this.maskNascimento.Location = new System.Drawing.Point(394, 398);
            this.maskNascimento.Mask = "00/00/0000";
            this.maskNascimento.Name = "maskNascimento";
            this.maskNascimento.Size = new System.Drawing.Size(154, 20);
            this.maskNascimento.TabIndex = 47;
            // 
            // maskCpf
            // 
            this.maskCpf.Location = new System.Drawing.Point(394, 327);
            this.maskCpf.Mask = "000.000.000-00";
            this.maskCpf.Name = "maskCpf";
            this.maskCpf.Size = new System.Drawing.Size(154, 20);
            this.maskCpf.TabIndex = 46;
            // 
            // lblNascimento
            // 
            this.lblNascimento.AutoSize = true;
            this.lblNascimento.BackColor = System.Drawing.Color.Transparent;
            this.lblNascimento.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNascimento.Location = new System.Drawing.Point(222, 393);
            this.lblNascimento.Name = "lblNascimento";
            this.lblNascimento.Size = new System.Drawing.Size(166, 23);
            this.lblNascimento.TabIndex = 45;
            this.lblNascimento.Text = "Data de Nascimento:";
            // 
            // lblCPF
            // 
            this.lblCPF.AutoSize = true;
            this.lblCPF.BackColor = System.Drawing.Color.Transparent;
            this.lblCPF.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCPF.Location = new System.Drawing.Point(342, 317);
            this.lblCPF.Name = "lblCPF";
            this.lblCPF.Size = new System.Drawing.Size(46, 23);
            this.lblCPF.TabIndex = 44;
            this.lblCPF.Text = "CPF:";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(394, 436);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(264, 20);
            this.txtEmail.TabIndex = 43;
            // 
            // txtNumeroTel
            // 
            this.txtNumeroTel.Location = new System.Drawing.Point(394, 364);
            this.txtNumeroTel.Name = "txtNumeroTel";
            this.txtNumeroTel.Size = new System.Drawing.Size(264, 20);
            this.txtNumeroTel.TabIndex = 42;
            // 
            // txtSobrenome
            // 
            this.txtSobrenome.Location = new System.Drawing.Point(394, 284);
            this.txtSobrenome.Name = "txtSobrenome";
            this.txtSobrenome.Size = new System.Drawing.Size(264, 20);
            this.txtSobrenome.TabIndex = 41;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(394, 246);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(264, 20);
            this.txtNome.TabIndex = 40;
            // 
            // lblNumeroTel
            // 
            this.lblNumeroTel.AutoSize = true;
            this.lblNumeroTel.BackColor = System.Drawing.Color.Transparent;
            this.lblNumeroTel.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeroTel.Location = new System.Drawing.Point(307, 351);
            this.lblNumeroTel.Name = "lblNumeroTel";
            this.lblNumeroTel.Size = new System.Drawing.Size(81, 23);
            this.lblNumeroTel.TabIndex = 39;
            this.lblNumeroTel.Text = "Telefone:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.BackColor = System.Drawing.Color.Transparent;
            this.lblEmail.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(327, 431);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(61, 23);
            this.lblEmail.TabIndex = 38;
            this.lblEmail.Text = "E-mail:";
            // 
            // lblSobrenome
            // 
            this.lblSobrenome.AutoSize = true;
            this.lblSobrenome.BackColor = System.Drawing.Color.Transparent;
            this.lblSobrenome.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSobrenome.Location = new System.Drawing.Point(285, 279);
            this.lblSobrenome.Name = "lblSobrenome";
            this.lblSobrenome.Size = new System.Drawing.Size(103, 23);
            this.lblSobrenome.TabIndex = 37;
            this.lblSobrenome.Text = "Sobrenome:";
            // 
            // lblNomeCliente
            // 
            this.lblNomeCliente.AutoSize = true;
            this.lblNomeCliente.BackColor = System.Drawing.Color.Transparent;
            this.lblNomeCliente.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeCliente.Location = new System.Drawing.Point(329, 241);
            this.lblNomeCliente.Name = "lblNomeCliente";
            this.lblNomeCliente.Size = new System.Drawing.Size(59, 23);
            this.lblNomeCliente.TabIndex = 36;
            this.lblNomeCliente.Text = "Nome:";
            // 
            // lblCadastroCliente
            // 
            this.lblCadastroCliente.AutoSize = true;
            this.lblCadastroCliente.BackColor = System.Drawing.Color.Transparent;
            this.lblCadastroCliente.Font = new System.Drawing.Font("Arial Narrow", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCadastroCliente.Location = new System.Drawing.Point(644, 171);
            this.lblCadastroCliente.Name = "lblCadastroCliente";
            this.lblCadastroCliente.Size = new System.Drawing.Size(110, 31);
            this.lblCadastroCliente.TabIndex = 48;
            this.lblCadastroCliente.Text = "Cadastro";
            // 
            // EnderecoCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1445, 656);
            this.Controls.Add(this.lblCadastroCliente);
            this.Controls.Add(this.maskNascimento);
            this.Controls.Add(this.maskCpf);
            this.Controls.Add(this.lblNascimento);
            this.Controls.Add(this.lblCPF);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtNumeroTel);
            this.Controls.Add(this.txtSobrenome);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblNumeroTel);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblSobrenome);
            this.Controls.Add(this.lblNomeCliente);
            this.Controls.Add(this.maskCep);
            this.Controls.Add(this.btnConcluirCadastro);
            this.Controls.Add(this.txtNumeroResidencia);
            this.Controls.Add(this.lblNumeroResidencia);
            this.Controls.Add(this.lblCep);
            this.Controls.Add(this.txtBairro);
            this.Controls.Add(this.lblBairro);
            this.Controls.Add(this.txtEndereco);
            this.Controls.Add(this.lblEndereco);
            this.DoubleBuffered = true;
            this.Name = "EnderecoCliente";
            this.Text = "EnderecoCliente";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEndereco;
        private System.Windows.Forms.TextBox txtEndereco;
        private System.Windows.Forms.Label lblBairro;
        private System.Windows.Forms.TextBox txtBairro;
        private System.Windows.Forms.Label lblCep;
        private System.Windows.Forms.Label lblNumeroResidencia;
        private System.Windows.Forms.TextBox txtNumeroResidencia;
        private System.Windows.Forms.Button btnConcluirCadastro;
        private System.Windows.Forms.MaskedTextBox maskCep;
        private System.Windows.Forms.MaskedTextBox maskNascimento;
        private System.Windows.Forms.MaskedTextBox maskCpf;
        private System.Windows.Forms.Label lblNascimento;
        private System.Windows.Forms.Label lblCPF;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtNumeroTel;
        private System.Windows.Forms.TextBox txtSobrenome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblNumeroTel;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblSobrenome;
        private System.Windows.Forms.Label lblNomeCliente;
        private System.Windows.Forms.Label lblCadastroCliente;
    }
}