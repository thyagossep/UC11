﻿namespace CAdastros_Pet
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.cadastroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.produtosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fármaciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.acessóriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.raçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.serviçosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.banhoETosaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.táxiDogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.táxiDogToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.contatoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastroToolStripMenuItem,
            this.produtosToolStripMenuItem,
            this.serviçosToolStripMenuItem,
            this.contatoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1333, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // cadastroToolStripMenuItem
            // 
            this.cadastroToolStripMenuItem.Name = "cadastroToolStripMenuItem";
            this.cadastroToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.cadastroToolStripMenuItem.Text = "Cadastro";
            this.cadastroToolStripMenuItem.Click += new System.EventHandler(this.cadastroToolStripMenuItem_Click);
            // 
            // produtosToolStripMenuItem
            // 
            this.produtosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fármaciaToolStripMenuItem,
            this.acessóriosToolStripMenuItem,
            this.raçõesToolStripMenuItem});
            this.produtosToolStripMenuItem.Name = "produtosToolStripMenuItem";
            this.produtosToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.produtosToolStripMenuItem.Text = "Produtos";
            // 
            // fármaciaToolStripMenuItem
            // 
            this.fármaciaToolStripMenuItem.Name = "fármaciaToolStripMenuItem";
            this.fármaciaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.fármaciaToolStripMenuItem.Text = "Fármacia";
            // 
            // acessóriosToolStripMenuItem
            // 
            this.acessóriosToolStripMenuItem.Name = "acessóriosToolStripMenuItem";
            this.acessóriosToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.acessóriosToolStripMenuItem.Text = "Acessórios";
            // 
            // raçõesToolStripMenuItem
            // 
            this.raçõesToolStripMenuItem.Name = "raçõesToolStripMenuItem";
            this.raçõesToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.raçõesToolStripMenuItem.Text = "Rações";
            // 
            // serviçosToolStripMenuItem
            // 
            this.serviçosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.banhoETosaToolStripMenuItem,
            this.táxiDogToolStripMenuItem,
            this.táxiDogToolStripMenuItem1});
            this.serviçosToolStripMenuItem.Name = "serviçosToolStripMenuItem";
            this.serviçosToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.serviçosToolStripMenuItem.Text = "Serviços";
            this.serviçosToolStripMenuItem.Click += new System.EventHandler(this.serviçosToolStripMenuItem_Click);
            // 
            // banhoETosaToolStripMenuItem
            // 
            this.banhoETosaToolStripMenuItem.Name = "banhoETosaToolStripMenuItem";
            this.banhoETosaToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.banhoETosaToolStripMenuItem.Text = "Banho";
            // 
            // táxiDogToolStripMenuItem
            // 
            this.táxiDogToolStripMenuItem.Name = "táxiDogToolStripMenuItem";
            this.táxiDogToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.táxiDogToolStripMenuItem.Text = "Tosa";
            this.táxiDogToolStripMenuItem.Click += new System.EventHandler(this.táxiDogToolStripMenuItem_Click);
            // 
            // táxiDogToolStripMenuItem1
            // 
            this.táxiDogToolStripMenuItem1.Name = "táxiDogToolStripMenuItem1";
            this.táxiDogToolStripMenuItem1.Size = new System.Drawing.Size(119, 22);
            this.táxiDogToolStripMenuItem1.Text = "Táxi Dog";
            // 
            // contatoToolStripMenuItem
            // 
            this.contatoToolStripMenuItem.Name = "contatoToolStripMenuItem";
            this.contatoToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.contatoToolStripMenuItem.Text = "Contato";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1333, 509);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.Text = " ALYPET";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cadastroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem produtosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem serviçosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contatoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fármaciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem acessóriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem raçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem banhoETosaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem táxiDogToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem táxiDogToolStripMenuItem1;
    }
}

